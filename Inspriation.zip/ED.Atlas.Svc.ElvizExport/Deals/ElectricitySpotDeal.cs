﻿using System;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Elviz;

namespace ED.Atlas.Svc.ElvizExport.Deals
{
    public interface IElectricitySpotDeal : IAtlasDealDto
    {
        string Serialize();
    }

    public class ElectricitySpotDeal : IElectricitySpotDeal
    {
        private readonly IElvizSerializerFactory _serializerFactory;

        public ElectricitySpotDeal(IElvizSerializerFactory serializerFactory)
        {
            _serializerFactory = serializerFactory;
        }

        public string Serialize()
        {
            return _serializerFactory.Get(DealTypeEnum.IntradayDeal).Serialize(this);
        }

        // Data section
        public DealTypeEnum DealType { get; set; }
        public string GUID { get; set; }
        public string ContractId { get; set; }
        public string PriceBasis { get; set; }
        public string Portefolio { get; set; }
        public string CounterPartyPortefolio { get; set; }
        public string ExecutionVenue { get; set; }
        public DateTime BeginDateTimeUtc { get; set; }
        public DateTime EndDateTimeUtc { get; set; }
        public string InstrumentType { get; set; }
        public string DayLoadProfile { get; set; }
        public string AtlasTrader { get; set; }
        public string Direction { get; set; }
        public Nullable<decimal> Price { get; set; }
        public string PriceCurrency { get; set; }
        public Nullable<decimal> Quantity { get; set; }
        public string QuantityUnit { get; set; }
        public string Comment { get; set; }
        public string EnergiDanmarkReference { get; set; }
        // TODO public bool IsOtc { get; set; }
        public DateTime TradeTimeUtc { get; set; }
        public DateTime TradeDateLocal { get; set; }
        public DateTime AcquiredTimeUtc { get; set; }
        public DateTime TransferDate { get; set; }
    }

    public class ElectricSpotDtoBuilder
    {
        private IElvizSerializerFactory _elvizSerializerFactory;
        private Guid _guid;

        public ElectricSpotDtoBuilder With(IElvizSerializerFactory elvizSerializerFactory)
        {
            _elvizSerializerFactory = elvizSerializerFactory;
            return this;
        }
        public ElectricSpotDtoBuilder With(Guid guid)
        {
            _guid = guid;
            return this;
        }
        public IElectricitySpotDeal Build()
        {
            ElectricitySpotDeal ret = new ElectricitySpotDeal(_elvizSerializerFactory);
            ret.GUID = _guid.ToString();
            return ret;
        }
    }
}
