﻿using System;
using ED.Atlas.Svc.ElvizExport.Settings;
using Microsoft.Owin.Hosting;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IWebRunner : IRunner
    {        
    }
    public class WebRunner : IWebRunner
    {
        private readonly IProgramSettings _programSettings;
        private IDisposable _owinService;

        public WebRunner(IProgramSettings programSettings)
        {
            _programSettings = programSettings;
        }

        public void Start()
        {
            _owinService = WebApp.Start<StartUp>($"http://+:{_programSettings.Port}");
        }

        public void Stop()
        {
            _owinService.Dispose();  // close web-service
        }
    }
}
