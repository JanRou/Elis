﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Deals;
using Newtonsoft.Json;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IIJsonDeserializer
    {        
    }
    public interface IJsonDeserializer<T> : IIJsonDeserializer
    {
        T Deserialize(string json);
    }
    public class JsonElectricitySpotDeserializer : IJsonDeserializer<IElectricitySpotDeal> 
    {
        public IElectricitySpotDeal Deserialize(string json)
        {
            return JsonConvert.DeserializeObject<ElectricitySpotDeal>(json);
        }
    }
}
