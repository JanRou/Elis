﻿namespace ED.Atlas.Svc.ElvizExport.Settings
{
    public interface IProgramSettings
    {
        string Port { get; }
        string FetchAtlasDealUrl { get; }
        string ElvizXmlExportTemporaryPath { get; }
        string ElvizXmlExportPath { get; }
        string ElvizXmlResultsPath { get; }        
        int ElivzExportWaitingTimeDurationInMinutes { get; }
    }
}