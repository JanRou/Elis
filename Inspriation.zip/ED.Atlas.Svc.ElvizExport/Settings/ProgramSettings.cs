﻿using System;
using System.Configuration;


namespace ED.Atlas.Svc.ElvizExport.Settings
{
    public class ProgramSettings : IProgramSettings
    {
        public string Port => ConfigurationManager.AppSettings["port"];

        public string ElvizXmlExportTemporaryPath => AddBacklashToEndOfPath(ConfigurationManager.AppSettings["ElvizXmlExportTemporaryPath"]);
        public string ElvizXmlExportPath => AddBacklashToEndOfPath(ConfigurationManager.AppSettings["ElvizXmlExportPath"]);
        public string ElvizXmlResultsPath => AddBacklashToEndOfPath(ConfigurationManager.AppSettings["ElvizXmlResultsPath"]);
        public string FetchAtlasDealUrl => ConfigurationManager.AppSettings["FetchAtlasDealUrl"];
        public int ElivzExportWaitingTimeDurationInMinutes
            => Convert.ToInt16(ConfigurationManager.AppSettings["ElivzExportMaxDurationInMinutes"]);

        public string AddBacklashToEndOfPath(string path)
        {
            return path.Substring(path.Length - 1) != "\\"? path + "\\" : path;
        }
    }
}