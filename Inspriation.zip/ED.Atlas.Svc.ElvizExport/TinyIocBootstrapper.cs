﻿using System;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Sagas;
using ED.Atlas.Svc.ElvizExport.Settings;
using ED.Atlas.Svc.ElvizExport.TimeoutMonitor;
using ED.Atlas.Svc.ElvizExport.Transition;
using log4net;
using log4net.Appender;
using log4net.Config;
using Nancy;
using Nancy.Bootstrapper;
using Nancy.TinyIoc;

namespace ED.Atlas.Svc.ElvizExport
{
    public class TinyIocBootstrapper : DefaultNancyBootstrapper
    {
        private static ProgramSettings _programSettings;
        private static EventQueue _eventQueue;
        private static FileHandlers _fileHandlers;
        private static ExportTimeoutMonitor _exportTimeoutMonitor;
        private static IntradaySagaBuilder _sagaBuilder;
        private static Dispatcher _dispatcher;
        private static ElvizSerializerFactory _elvizSerializerFactory;
        private static JsonDeserializerFactory _jsonDeserializerFactory;
        private static SharedRestCommunication _sharedRestCommunication;
        private static IDateTimeNow _dateTimeNow;
        //private static LoggerManager _loggerManager;

        public void Register()
        {

            // Log4Net
            XmlConfigurator.Configure();
        
            var container = TinyIoCContainer.Current;
            container.AutoRegister();
            _programSettings = container.Resolve<ProgramSettings>();
            _eventQueue = new EventQueue("", new EdLogger<EventQueue>());
            container.Register<IEventQueue, EventQueue>(_eventQueue);
            container.Register<IEdLog<FileHandlers>, EdLogger<FileHandlers>>();
            _fileHandlers = container.Resolve<FileHandlers>();
           // _loggerManager = container.Resolve<LoggerManager>();
            _elvizSerializerFactory = CreateElvizSerializerFactory();
            container.Register<IElvizSerializerFactory, ElvizSerializerFactory>(_elvizSerializerFactory);
            _jsonDeserializerFactory = CreateJsonDeserializerFactory();
            container.Register<IJsonDeserializerFactory, JsonDeserializerFactory>(_jsonDeserializerFactory);
            _dateTimeNow = new DateTimeNow();
            _exportTimeoutMonitor = new ExportTimeoutMonitor(container.Resolve<ITimer>()
                , _programSettings.ElivzExportWaitingTimeDurationInMinutes, _eventQueue, _dateTimeNow);
            container.Register<IExportTimeoutMonitor, ExportTimeoutMonitor>(_exportTimeoutMonitor);
            _sharedRestCommunication = new SharedRestCommunication();
            container.Register<ISharedRestCommunication, SharedRestCommunication>(_sharedRestCommunication);
            _sagaBuilder = new IntradaySagaBuilder(_elvizSerializerFactory, _programSettings, _exportTimeoutMonitor,
                _fileHandlers, _sharedRestCommunication);
            _dispatcher = new Dispatcher(  _sagaBuilder.Build()
                , _eventQueue, _fileHandlers, new EdLogger<Dispatcher>());
            container.Register<IEventDispatcher, Dispatcher>(_dispatcher);
        }

        protected override void ConfigureApplicationContainer(TinyIoCContainer container)
        {
            base.ConfigureApplicationContainer(container);
            // Reuse previous instances so the rest of the application uses SAME instances
            //container.Register<ILoggerManager, LoggerManager>(_loggerManager);
            container.Register<IProgramSettings, ProgramSettings>(_programSettings);
            container.Register<IEventQueue, EventQueue>(_eventQueue);
            container.Register<IFileHandlers, FileHandlers>(_fileHandlers);
            container.Register<IExportTimeoutMonitor, ExportTimeoutMonitor>(_exportTimeoutMonitor);
            container.Register<ISagaBuilder, IntradaySagaBuilder>(_sagaBuilder);
            container.Register<IEventDispatcher, Dispatcher>(_dispatcher);
            container.Register<IElvizSerializerFactory, ElvizSerializerFactory>(_elvizSerializerFactory);
            container.Register<IJsonDeserializerFactory, JsonDeserializerFactory>(_jsonDeserializerFactory);
        }

        //protected override void ApplicationStartup(TinyIoCContainer container, IPipelines pipelines)
        //{
        //    base.ApplicationStartup(container, pipelines);
        //}

        public JsonDeserializerFactory CreateJsonDeserializerFactory()
        {
            JsonDeserializerFactory deserializerFactory = new JsonDeserializerFactory();
            deserializerFactory.Set(DealTypeEnum.IntradayDeal, new JsonElectricitySpotDeserializer());
            return deserializerFactory;
        }

        public ElvizSerializerFactory CreateElvizSerializerFactory()
        {
            ElvizSerializerFactory ret = new ElvizSerializerFactory();
            ret.Add(DealTypeEnum.IntradayDeal, new SpotDealSerializer());
            return ret;
        }

    }
}
