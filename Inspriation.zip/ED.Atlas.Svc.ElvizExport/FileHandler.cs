﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Deals;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IFileHandler
    {
        Guid FileId { get; }
        StateEnum State { get; set; }
        string Filename { get; set; }
        string XmlBuffer { get; set; }
        DealTypeEnum DealType { get; }
        IElectricitySpotDeal Deal { get; set; }
        ElvizExportStatus ElvizExportStatus { get; set; }
        string ExportErrorMessage { get; set; }

    }
    public class FileHandler : IFileHandler
    {
        public FileHandler(IElectricitySpotDeal deal)
        {
            Deal = deal;
            _fileId = Guid.Parse(deal.GUID);
        }

        private Guid _fileId;
        public Guid FileId { get {return _fileId;} }
        public StateEnum State { get; set; }
        public string Filename { get; set; }
        public string XmlBuffer { get; set; }

        public DealTypeEnum DealType
        {
            get { return Deal.DealType; }
        }
        public IElectricitySpotDeal Deal { get; set; }
        public ElvizExportStatus ElvizExportStatus { get; set; }
        public string ExportErrorMessage { get; set; }
    }

    public class FileHandlerBuilder
    {
        private IElectricitySpotDeal _deal;
        private StateEnum _state = StateEnum.Ready;
        private string _fileName = "";
        private string _xmlBuffer = "";
        private ElvizExportStatus _elvizExportStatus = ElvizExportStatus.Undefined;

        public FileHandlerBuilder With(IElectricitySpotDeal deal)
        {
            _deal = deal;
            return this;
        }
        public FileHandlerBuilder With(StateEnum state)
        {
            _state = state;
            return this;
        }
        public FileHandlerBuilder With(string fileName)
        {
            _fileName = fileName;
            return this;
        }
        public FileHandlerBuilder WithXmlBuffer(string xmlBuffer)
        {
            _xmlBuffer = xmlBuffer;
            return this;
        }

        public FileHandlerBuilder WithElvizExportStatus(ElvizExportStatus elvizExportStatus)
        {
            _elvizExportStatus = elvizExportStatus;
            return this;
        }

        public IFileHandler Build()
        {
            return new FileHandler(_deal) { State = _state, Filename = _fileName, XmlBuffer = _xmlBuffer, ElvizExportStatus = _elvizExportStatus};
        }
    }
}
