﻿using System;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Deals;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;
using ED.Atlas.Svc.ElvizExport.Settings;
using ED.Atlas.Svc.ElvizExport.DTO;
using Nancy;
using Nancy.Extensions;
using Nancy.Responses;
using Newtonsoft.Json;
using RestSharp;

namespace ED.Atlas.Svc.ElvizExport.Runs
{
    public class RunsModule : NancyModule

    {
        private readonly IEventQueue _eventQueue;
        private readonly IFileHandlers _fileHandlers;
        private readonly IJsonDeserializerFactory _jsonDeserializerFactory;
        private readonly IProgramSettings _programSettings;

        public RunsModule(IProgramSettings programSettings, IEventQueue eventQueue, IFileHandlers fileHandlers
            , IJsonDeserializerFactory jsonDeserializerFactory) : base("v1")
        {
            _programSettings = programSettings;
            _eventQueue = eventQueue;
            _fileHandlers = fileHandlers;
            _jsonDeserializerFactory = jsonDeserializerFactory;

            // Used by the ElvizFileMonitor
            Post["/fileIds"] = p =>
            {
                var fileId = Request.Body.AsString();

                var guid = fileId.Substring(0, fileId.LastIndexOf(".", StringComparison.Ordinal));

                var fileHandler = _fileHandlers.Get(Guid.Parse(guid));
                var result = fileHandler != null;
                if (result)
                {
                    // Filehandler exist for Guid
                    _eventQueue.Enqueue(new HandlerEvent {Event = EventEnum.Result, Guid = fileHandler.FileId});
                }
                return new JsonResponse(result, new DefaultJsonSerializer());
            };

            //Post["/deals", true] = async (p, ct) =>
            Post["/deals"] = p =>
            {
                var fileId = Request.Body.AsString();

                var atlasDealDto = JsonConvert.DeserializeObject<DTO.AtlasDealDto>(fileId);


                var client = new RestClient(_programSettings.FetchAtlasDealUrl);
                var request = new RestRequest($"v1/deals/{atlasDealDto.AtlasDealGuid}", Method.GET);

                //var response = await client.ExecuteTaskAsync(request);
                var response = client.Execute(request);
                HttpStatusCode ret = HttpStatusCode.OK;
                if ((HttpStatusCode) response.StatusCode == HttpStatusCode.OK)
                {
                    try
                    {
                        EnqueueFileHandler(response, _fileHandlers, _eventQueue);
                    }
                    catch (Exception  exception)
                    {
                        ret = HttpStatusCode.InternalServerError;
                        // TODO log
                    }
                }
                else
                {
                    ret = HttpStatusCode.NoResponse;
                }
                return ret;
            };
        }

        private bool EnqueueFileHandler(IRestResponse response, IFileHandlers fileHandlers, IEventQueue eventQueue)
        {
            var deal =
                _jsonDeserializerFactory.Get<IElectricitySpotDeal>(DealTypeEnum.IntradayDeal)
                    .Deserialize(response.Content);
            bool result = fileHandlers.TryAdd(new FileHandlerBuilder().With(deal).Build());
            if (result)
            {
                // Filehandler don't exist, it is added
                eventQueue.Enqueue(new HandlerEvent {Event = EventEnum.NewFile, Guid = Guid.Parse(deal.GUID)});
            }
            return result;
        }
    }
}