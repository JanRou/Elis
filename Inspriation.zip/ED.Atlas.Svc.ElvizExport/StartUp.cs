﻿using Owin;

namespace ED.Atlas.Svc.ElvizExport
{
    public class StartUp
    {
        public void Configuration(IAppBuilder appBuilder)
        {
            appBuilder.UseNancy();
        }
    }
}