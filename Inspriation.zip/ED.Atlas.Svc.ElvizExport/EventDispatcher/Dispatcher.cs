﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Ed.Shared.Extensions;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Sagas;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.EventDispatcher
{
    public interface IEventDispatcher
    {
        void Dispatch();
    }

    public class Dispatcher : IEventDispatcher
    {
        private ISaga _saga;
        private IEventQueue _eventQueue;
        private IFileHandlers _fileHandlers;
        private readonly IEdLog<Dispatcher> _edLog;

        public Dispatcher(ISaga saga, IEventQueue eventQueue, IFileHandlers fileHandlers, IEdLog<Dispatcher> edLog)
        {
            _saga = saga;
            _eventQueue = eventQueue;
            _fileHandlers = fileHandlers;
            _edLog = edLog;
        }

        public void Dispatch()
        {
            // Main event pump loop of event dispatcher.
            // The eventQueue is blocking and is released by a Evenqueue.Complete() call.

            _edLog.Debug("Starting Dispacher");
            foreach (IEvent evnt in _eventQueue.GetEnumerable())
            {
                _edLog.Guid = evnt.Guid;
                _edLog.DebugFormat($"Event: {evnt.Event}");
                ITransition transition = null;
                IFileHandler fileHandler = _fileHandlers.Get(evnt.Guid);
                bool ok = fileHandler != null;
                if (ok)
                {
                    transition = _saga.GetTransition(fileHandler.State, evnt.Event);
                    ok = transition != null;
                }
                if (ok)
                {
                    _edLog.DebugFormat($"Transition: {transition}");
                    IEvent resultEvent = transition.Execute(fileHandler);
                    if ((resultEvent.Event != EventEnum.None) && (resultEvent.Event != EventEnum.Done))
                    {
                        // Some transition don't return a valid Event, because the expected next 
                        // event comes later or from external source
                        _eventQueue.Enqueue(resultEvent);
                    }
                    fileHandler.State = _saga.GetNextState(fileHandler.State, transition);
                    _edLog.Debug($"New State {fileHandler.State}");
                }
                if ( ok && (fileHandler.State == StateEnum.Done))
                {
                    // When state is done we remove the file handler
                    _fileHandlers.Remove(evnt.Guid);
                    _edLog.Debug($"Removed  {evnt.Guid}");
                }
                if (!ok)
                {
                    LogError(evnt, fileHandler, transition);
                }
            }
            _edLog.Debug("Stopping Dispatcher, no more Events");
        }

        private void LogError(IEvent evnt, IFileHandler fileHandler, ITransition transition)
        {

            if ( fileHandler == null )
            {
                _edLog.Error(
                    $"Filehandler was null for guid {evnt.Guid}");

            }
            if ( transition == null )
            {
                _edLog.Error(
                    $"Transition was null, Event: {evnt.Event}, Filehandler.State: {fileHandler?.State}");
            }

        }
    }
}
