﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Log;

namespace ED.Atlas.Svc.ElvizExport.EventDispatcher
{
    public interface IEventQueue
    {
        void Enqueue(IEvent evnt);
        IEvent Dequeue();
        int Count();
        void Complete();
        IEnumerable<IEvent> GetEnumerable();
    }
    public class EventQueue : IEventQueue
    {
        private readonly IEdLog<EventQueue> _log;
        public string Name { get; set; }
        private BlockingCollection<IEvent> _queue;

        public EventQueue(string name, IEdLog<EventQueue> log)
        {
            _log = log;
            Name = name;
            _queue = new BlockingCollection<IEvent>(new ConcurrentQueue<IEvent>());;
        }
        public void Enqueue(IEvent evnt)
        {
            _queue.Add(evnt);
        }

        public IEvent Dequeue()
        {
            IEvent ret = null;
            try
            {
                ret = _queue.Take();
            }
            catch (InvalidOperationException ioe)
            {
                // TODO ?? log ioe
                ret = null;
            }
            return ret;
        }

        public void Complete()
        {
            _queue.CompleteAdding();
        }

        public int Count()
        {
            return _queue.Count;
        }

        public IEnumerable<IEvent> GetEnumerable()
        {
            return _queue.GetConsumingEnumerable();
        }
    }
}
