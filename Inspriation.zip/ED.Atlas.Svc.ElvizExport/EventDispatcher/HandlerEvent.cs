﻿using System;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport.EventDispatcher
{
    public class HandlerEvent : IEvent
    {
        public EventEnum Event { get; set; }
        public Guid Guid { get; set; }
    }
}