﻿using System;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport.EventDispatcher
{
    public interface IEvent
    {
        EventEnum Event { get; set; }
        Guid Guid { get; set; }        
    }
}