﻿using System;
using System.Collections.Generic;
using System.Linq;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport.TimeoutMonitor
{
    public interface IDateTimeNow
    {
        DateTime Now { get; }
    }
    public class DateTimeNow : IDateTimeNow
    {
        public DateTime Now => DateTime.Now;
    }

    public class ExportTimeoutMonitor : IExportTimeoutMonitor
    {
        private readonly IEventQueue _eventQueue;
        private readonly IDateTimeNow _dateTimeNow;
        private readonly ICollection<FileTimeOut> _fileTimeOuts;
        private readonly ITimer _timer;
        private readonly TimeSpan _waitTime;
        private readonly object _lock = new object();

        public ExportTimeoutMonitor(ITimer timer, int waitingTimeMinutes, IEventQueue eventQueue, IDateTimeNow dateTimeNow)
        {
            _fileTimeOuts = new List<FileTimeOut>();
            _waitTime = new TimeSpan(0, 0, waitingTimeMinutes, 0);
            _eventQueue = eventQueue;
            _dateTimeNow = dateTimeNow;
            _timer = timer;
            _timer.TimeIsUp += 
                (sender, args) =>
                    {
                        lock (_lock)
                        {
                            DateTime now = _dateTimeNow.Now + new TimeSpan(0, 0, 0, 10); // lets look 10 second forward
                            // Get list of expired timers 10 seconds a head, so we have time to execute
                            List<FileTimeOut> timeOuts =
                                _fileTimeOuts.Where(x => x.TimeForExecution <= now).OrderBy(x => x.TimeForExecution).ToList();
                            foreach (FileTimeOut fileTimeOut in timeOuts)
                            {
                                // Send event
                                TimerOnTimeIsUp(fileTimeOut.FileId);
                                // remove timer from timer out collection
                                _fileTimeOuts.Remove(fileTimeOut);
                            }
                            // get next time out
                            FileTimeOut timeOut = _fileTimeOuts.OrderBy(x => x.TimeForExecution).FirstOrDefault();
                            if (timeOut != null)
                            {
                                // found a timer to set, which is the first timer to expire
                                SetTimer(timeOut.TimeForExecution, now);
                            }
                        }
                    };
        }

        public void Register(Guid fileId)
        {
            DateTime now = _dateTimeNow.Now;
            var fileTimeOut = new FileTimeOut(fileId, now + _waitTime);

            lock (_lock)
            {
                if (!_fileTimeOuts.Any())
                {
                    SetTimer(fileTimeOut.TimeForExecution, now);
                }
                _fileTimeOuts.Add(fileTimeOut);
            }
        }

        public void Unregister(Guid fileId)
        {
            lock (_lock)
            {
                FileTimeOut fileTimeOut = _fileTimeOuts.FirstOrDefault(x => x.FileId == fileId);
                if (fileTimeOut != null)
                {
                    _fileTimeOuts.Remove(fileTimeOut);

                    var nextTimerObject = _fileTimeOuts.OrderBy(x => x.TimeForExecution).FirstOrDefault();
                    if (nextTimerObject != null)
                    {
                        SetTimer(nextTimerObject.TimeForExecution, _dateTimeNow.Now);
                    }
                }
            }
        }

        private void SetTimer(DateTime timeOut, DateTime now)
        {
            // this may theoretical not work, because the call to this method may take long time
            // this timeSpan become negative. In this case we set a timespan of 1 ms.
            // is solved. 
            var timeSpan = timeOut > now ? timeOut - now : new TimeSpan(0,0,0,0,1); 
            _timer.SetTimer(timeSpan);
        }

        private void TimerOnTimeIsUp(Guid fileId)
        {
            _eventQueue.Enqueue(new HandlerEvent {Guid = fileId, Event = EventEnum.Timeout});
        }
    }

}