﻿using System;
using System.Threading;

namespace ED.Atlas.Svc.ElvizExport.TimeoutMonitor
{
    public class Timer : IDisposable, ITimer
    {
        private readonly System.Threading.Timer _timer;
        private bool _disposed;

        public Timer()
        {
            _timer = new System.Threading.Timer(RaiseTimeIsUp, null, Timeout.Infinite, Timeout.Infinite);
        }

        private void RaiseTimeIsUp(object state)
        {
            var handler = TimeIsUp;
            handler?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Raised when the time has elapsed.
        /// </summary>
        public event EventHandler TimeIsUp;

        /// <summary>
        /// Instructs the time to fire an event when time given has elapsed.
        /// If a the timer has already been set, the old time is cleared.
        /// </summary>
        /// <param name="time">Time until the TimeIsUp event should be raised</param>
        public void  SetTimer(TimeSpan time)
        {
            if (time != TimeSpan.MaxValue)
            {
                _timer.Change(time.Duration(), Timeout.InfiniteTimeSpan);
            }
        }

        #region Implementation of IDisposable

        protected void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    _timer.Dispose();
                }

                // There are no unmanaged resources to release, but
                // if we add them, they need to be released here.
            }
            _disposed = true;

            // If it is available, make the call to the
            // base class's Dispose(Boolean) method
        }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}
