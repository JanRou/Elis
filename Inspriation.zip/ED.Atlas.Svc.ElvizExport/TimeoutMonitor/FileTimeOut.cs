﻿using System;

namespace ED.Atlas.Svc.ElvizExport.TimeoutMonitor
{
    public class FileTimeOut
    {
        public Guid FileId { get; set; }
        public DateTime TimeForExecution { get; set; }

        public FileTimeOut(Guid fileId, DateTime timeForExecution)
        {
            TimeForExecution = timeForExecution;
            FileId = fileId;
        }
    }
}