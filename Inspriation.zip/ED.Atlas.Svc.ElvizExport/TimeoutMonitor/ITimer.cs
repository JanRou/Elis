﻿using System;

namespace ED.Atlas.Svc.ElvizExport.TimeoutMonitor
{
    public interface ITimer
    {
        event EventHandler TimeIsUp;

        void Dispose();
        void SetTimer(TimeSpan time);
    }
}