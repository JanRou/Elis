﻿using System;

namespace ED.Atlas.Svc.ElvizExport.TimeoutMonitor
{
    public interface IExportTimeoutMonitor
    {
        void Register(Guid fileId);
        void Unregister(Guid fileId);
    }
}