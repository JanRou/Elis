﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IRunner
    {
        void Start();
        void Stop();
    }
}
