﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IJsonDeserializerFactory
    {
         IJsonDeserializer<T> Get<T>(DealTypeEnum dealType);
         void Set<T>(DealTypeEnum dealType, IJsonDeserializer<T> jsonDeserializer);
    }
    public class JsonDeserializerFactory : IJsonDeserializerFactory
    {
        private Dictionary< DealTypeEnum, IIJsonDeserializer> _jsonDeserializers;

        public JsonDeserializerFactory()
        {
            _jsonDeserializers = new Dictionary<DealTypeEnum, IIJsonDeserializer>();
        }
        
        public IJsonDeserializer<T> Get<T>(DealTypeEnum dealType)
        {
            return _jsonDeserializers.ContainsKey(dealType) ? _jsonDeserializers[dealType] as IJsonDeserializer<T> : null ;
        }

        public void Set<T>(DealTypeEnum dealType, IJsonDeserializer<T> jsonDeserializer)
        {
            _jsonDeserializers.Add(dealType, jsonDeserializer);
        }
    }
}
