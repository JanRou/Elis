﻿using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IBackendRunner : IRunner
    {
    }
    public class BackendRunner : IBackendRunner
    {
        private IEventQueue _eventQueue;
        private readonly IEventDispatcher _dispatcher;
        private Task _dispatcherTask;

        public BackendRunner
            (
                IEventQueue eventQueue
            ,   IEventDispatcher dispatcher
            )
        {
            _eventQueue = eventQueue;
            _dispatcher = dispatcher;
        }

        public void Start()
        {
            // TODO (nice to have) read persisted filehandlers
            _dispatcherTask = Task.Run(() => _dispatcher.Dispatch());
        }

        public void Stop()
        {
            _eventQueue.Complete();         // stop event queue and event pump loop
            _dispatcherTask.Wait();         // wait dispatcher to stop, because the event queu is completed
            // TODO: (nice to have) Clear or persist filehandlers
        }

        public Task DispatcherTask { get { return _dispatcherTask;} }

    }
}
