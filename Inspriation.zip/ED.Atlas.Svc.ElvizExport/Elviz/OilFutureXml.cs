﻿using System;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
   public class OilFutureXml : ElvizXmlBase
    {
       private readonly DealInsertTransactionOilFuture _oilFuture = new DealInsertTransactionOilFuture();
       private readonly DealInsertTransactionOilFutureInstrumentData _instrumentData = new DealInsertTransactionOilFutureInstrumentData();
       private readonly DealInsertTransactionOilFutureSettlementData _settlementData = new DealInsertTransactionOilFutureSettlementData();

       public OilFutureXml()
       {
           _oilFuture.InstrumentData = _instrumentData;
           _oilFuture.SettlementData = _settlementData;
           Transaction.Item = _oilFuture;
       }
       #region GetSet Instrumentdata
       public override TimezoneType Timezone
       {
           set { _Timezone = value; _instrumentData.Timezone = value; TimezoneSpecified = true; }
       }

       public override bool TimezoneSpecified
       {
           set { _TimezoneSpecified = value; _instrumentData.TimezoneSpecified = value; }
       }

       public override ExecutionVenueType ExecutionVenue
       {
           set { _ExecutionVenue = value; _instrumentData.ExecutionVenue = value; }
       }

       public override string PriceBasis
       {
           set { _PriceBasis = value; _instrumentData.PriceBasis = value; }
       }

       public override DateTime FromDate
       {
           set { _FromDate = value; _instrumentData.FromDate = value; }
       }

       public override DateTime ToDate
       {
           set { _ToDate = value; _instrumentData.ToDate = value; }
       }

       public override object Item
       {
           set { _Item = value; _instrumentData.Item = value; }
       }
       #endregion GetSet InstrumentData

       #region GetSet SettlementData
       public override double Quantity
       {
           set
           {
               _Quantity = value;
               _settlementData.Quantity = value;
           }
       }

       public override QuantityUnitTypeOil QuantityUnitOil
       {
           set
           {
               _QuantityUnitOil = value;
               _settlementData.QuantityUnit = value;
           }
       }
       public override double Price
       {
           set { _Price = value; _settlementData.Price = value; }
       }

       public override CurrencyType Currency
       {
           set { _Currency = value; _settlementData.Currency = value; }
       }

       public override PriceVolumeUnitTypeOil PriceVolumeUnitTypeOil { set { _PriceVolumeUnitTypeOil = value;
           _settlementData.PriceVolumeUnit = value;
       } }

       public override CurrencySourceType CurrencySource
       {
           set { _CurrencySource = value; _settlementData.CurrencySource = value; }
       }

       public override ClearingType Clearing
       {
           set { _Clearing = value; _settlementData.Clearing = value; }
       }

       public override CurrencyType ClearingCurrency
       {
           set { _ClearingCurrency = value; _settlementData.ClearingCurrency = value; }
       }

       public override double ClearingFee
       {
           set { _ClearingFee = value; _settlementData.ClearingFee = value; ClearingFeeSpecified = true; }
       }

       public override bool ClearingFeeSpecified
       {
           set { _ClearingFeeSpecified = value; _settlementData.ClearingFeeSpecified = value; }
       }

       public override double BrokerTradingFee
       {
           set { _BrokerTradingFee = value; _settlementData.BrokerTradingFee = value; BrokerTradingFeeSpecified = true; }
       }

       public override bool BrokerTradingFeeSpecified
       {
           set { _BrokerTradingFeeSpecified = value; _settlementData.BrokerTradingFeeSpecified = value; }
       }

       public override CurrencyType BrokerCurrency
       {
           set { _BrokerCurrency = value; _settlementData.BrokerCurrency = value; }
       }

       public override double BrokerFee
       {
           set { _BrokerFee = value; _settlementData.BrokerFee = value; BrokerFeeSpecified = true; }
       }

       public override bool BrokerFeeSpecified
       {
           set { _BrokerFeeSpecified = value; _settlementData.BrokerFeeSpecified = value; }
       }

       public override CurrencyType BrokerFeeCurrency
       {
           set { _BrokerFeeCurrency = value; _settlementData.BrokerFeeCurrency = value; BrokerFeeCurrencySpecified = true; }
       }

       public override bool BrokerFeeCurrencySpecified
       {
           set { _BrokerFeeCurrencySpecified = value; _settlementData.BrokerFeeCurrencySpecified = value; }
       }

       public override double TradingFee
       {
           set { _TradingFee = value; _settlementData.TradingFee = value; TradingFeeSpecified = true; }
       }

       public override bool TradingFeeSpecified
       {
           set { _TradingFeeSpecified = value; _settlementData.TradingFeeSpecified = value; }
       }

       public override CurrencyType TradingFeeCurrency
       {
           set { _TradingFeeCurrency = value; _settlementData.TradingFeeCurrency = value; TradingFeeCurrencySpecified = true; }
       }

       public override string Broker
       {
           set { _Broker = value; _settlementData.Broker = value; }
       }

       #endregion GetSet SettleementData

       }
}
