﻿using System;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class GreenCertificateForwardXml : ElvizXmlBase
    {
        readonly DealInsertTransactionGreenCertificateForward _greenCertificateForward = new DealInsertTransactionGreenCertificateForward();
        readonly DealInsertTransactionGreenCertificateForwardInstrumentData _instrumentData = new DealInsertTransactionGreenCertificateForwardInstrumentData();
        readonly DealInsertTransactionGreenCertificateForwardSettlementData _settlementData = new DealInsertTransactionGreenCertificateForwardSettlementData();

        public GreenCertificateForwardXml()
        {
            _greenCertificateForward.InstrumentData = _instrumentData;
            _greenCertificateForward.SettlementData = _settlementData;
            Transaction.Item = _greenCertificateForward;
        }

        //InstrumentData

        #region GetSet _instrumentData     
        public override TimezoneType Timezone
        {
            set { _Timezone = value; _instrumentData.Timezone = value; TimezoneSpecified = true; }
        }
        
        public override string FromCountry
        {
            set { _fromCountry = value;
                _instrumentData.FromCountry = value;
            }
        }
        
        public override string ToCountry
        {
            set { _toCountry = value;
                _instrumentData.ToCountry = value;
            }
        }
        
        public override string CertificateType
        {
            set{ _certificateType = value; _instrumentData.CertificateType = value; }
        }
        
        public override DateTime TransferDate
        {
            set { _transferDate = value; _instrumentData.TransferDate = value; }
        }

        public override bool TimezoneSpecified
        {
            set { _TimezoneSpecified = value; _instrumentData.TimezoneSpecified = value; }
        }
        
        public override ExecutionVenueType ExecutionVenue
        {
            set { _ExecutionVenue = value; _instrumentData.ExecutionVenue = value; }
        }
      
        public override DateTime FromDate
        {
            set { _FromDate = value; _instrumentData.FromDate = value; }
        }
        
        public override DateTime ToDate
        {
            set { _ToDate = value; _instrumentData.ToDate = value; }
        }
     
        public override string PhysicalDeliveryAreaName
        {
            get { return _PhysicalDeliveryAreaName; }
            set
            {
                _PhysicalDeliveryAreaName = value;
                Physical.DeliveryArea = new BalanceAreaType {AreaName = value};
            }
        }

        #endregion GetSet _instrumentData

        //SettlementData

        #region GetSet SettlementData      
        public override double Quantity
        {
            set { _Quantity = value; _settlementData.Quantity = value; }
        }
        
        public override QuantityUnitType QuantityUnit
        {
            set { _QuantityUnit = value; _settlementData.QuantityUnit = value; }
        }
        
        public override double Price
        {
            set { _Price = value; _settlementData.Price = value; }
        }
        
        public override CurrencyType Currency
        {
            set { _Currency = value; _settlementData.Currency = value; }
        }
       
        public override CurrencySourceType CurrencySource
        {
            set { _CurrencySource = value; _settlementData.CurrencySource = value; }
        }
        
        public override ClearingType Clearing
        {
            set { _Clearing = value; _settlementData.Clearing = value; }
        }
        
        public override CurrencyType ClearingCurrency
        {
            set { _ClearingCurrency = value; _settlementData.ClearingCurrency = value; }
        }
        
        public override double ClearingFee
        {
            set { _ClearingFee = value; _settlementData.ClearingFee = value; ClearingFeeSpecified = true; }
        }
        
        public override bool ClearingFeeSpecified
        {
            set { _ClearingFeeSpecified = value; _settlementData.ClearingFeeSpecified = value; }
        }
        
        public override double BrokerTradingFee
        {
            set { _BrokerTradingFee = value; _settlementData.BrokerTradingFee = value; BrokerTradingFeeSpecified = true; }
        }
        
        public override bool BrokerTradingFeeSpecified
        {
            set { _BrokerTradingFeeSpecified = value; _settlementData.BrokerTradingFeeSpecified = value; }
        }
        
        public override CurrencyType BrokerCurrency
        {
            set { _BrokerCurrency = value; _settlementData.BrokerCurrency = value; }
        }
        
        public override double BrokerFee
        {
            set { _BrokerFee = value; _settlementData.BrokerFee = value; BrokerFeeSpecified = true; }
        }
        
        public override bool BrokerFeeSpecified
        {
            set { _BrokerFeeSpecified = value; _settlementData.BrokerFeeSpecified = value; }
        }
        
        public override CurrencyType BrokerFeeCurrency
        {
            set { _BrokerFeeCurrency = value; _settlementData.BrokerFeeCurrency = value; BrokerFeeCurrencySpecified = true; }
        }
        
        public override bool BrokerFeeCurrencySpecified
        {
            set { _BrokerFeeCurrencySpecified = value; _settlementData.BrokerFeeCurrencySpecified = value; }
        }
        
        public override double TradingFee
        {
            set { _TradingFee = value; _settlementData.TradingFee = value; TradingFeeSpecified = true; }
        }
        
        public override bool TradingFeeSpecified
        {
            set { _TradingFeeSpecified = value; _settlementData.TradingFeeSpecified = value; }
        }
        
        public override CurrencyType TradingFeeCurrency
        {
            set { _TradingFeeCurrency = value; _settlementData.TradingFeeCurrency = value; TradingFeeCurrencySpecified = true; }
        }
        
        public override bool TradingFeeCurrencySpecified
        {
            set { _TradingFeeCurrencySpecified = value; _settlementData.TradingFeeCurrencySpecified = value; }
        }
        
        public override double CommissionFee
        {
            set { _CommissionFee = value; _settlementData.CommissionFee = value; CommissionFeeSpecified = true; }
        }
        
        public override bool CommissionFeeSpecified
        {
            set { _CommissionFeeSpecified = value; _settlementData.CommissionFeeSpecified = value; }
        }
        
        public override CurrencyType CommissionFeeCurrency
        {
            set { _CommissionFeeCurrency = value; _settlementData.CommissionFeeCurrency = value; CommissionFeeCurrencySpecified = true; }
        }
        
        public override bool CommissionFeeCurrencySpecified
        {
            set { _CommissionFeeCurrencySpecified = value; _settlementData.CommissionFeeCurrencySpecified = value; }
        }
        
        public override string Broker
        {
            set { _Broker = value; _settlementData.Broker = value; }
        }
        
        public override string SettlementRuleName
        {
            set { _SettlementRuleName = value; _settlementData.SettlementRuleName = value; }
        }
        
        public override bool AuthorisationConfirmed
        {
            set { _AuthorisationConfirmed = value; _settlementData.AuthorisationConfirmed = value; }
        }
        
        #endregion GetSet _settlementData
    }
}
