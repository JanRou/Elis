﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class Serialization
    {

        public static string Serialize<T>(T t)
        {
            string strBuf;
            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (XmlWriter writer = XmlWriter.Create(memoryStream))
                {
                    var serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
                    serializer.Serialize(writer, t);
                    writer.Flush();
                    memoryStream.Position = 0;
                }
                using (StreamReader streamReader = new StreamReader(memoryStream))
                {
                    strBuf = streamReader.ReadToEnd();
                }
            }
            return strBuf;
        }
    }
}
