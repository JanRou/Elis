﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Serialization;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class ElvizXmlBase
    {
         private DealInsert _insert = new DealInsert();
         public long DealId { get; set; }

        //MetaData
        #region Declare MetaData
        private readonly DealInsertMetaData _metaData = new DealInsertMetaData();
        private String _authenticationToken;
        private string _messageId;
        #endregion Declare MetaData

        //Transaction
        #region Declare Transaction
        public DealInsertTransaction Transaction = new DealInsertTransaction();
        private TransactionTypeType _transactionType;
        private DealInsertTransactionDealType _dealType;
        #endregion Declare Transaction

        //Portfolio
        #region Declare Portfolio
        private readonly DealInsertTransactionPortfolios _portfolios = new DealInsertTransactionPortfolios();
        private BuySellType _buySell;
        private String _counterpartyPortfolio;
        private String _portfolio;
        #endregion Declare Portfolio

        //DealDetails
        #region Declare DealDetails
        private readonly DealInsertTransactionDealDetails _dealDetails = new DealInsertTransactionDealDetails();
        private StatusType _status;
        private String _trader;
        private DateTime _tradeDate;
        private Boolean _confirmedByBroker;
        private Boolean _confirmedByCounterparty;
        private Boolean _authorised;
        private Boolean _paid;
        private DateTime _timeSpampClearedUtc;
        private DateTime _timeSpampConfirmedBrokerUtc;
        private DateTime _timeSpampConfirmedCounterPartyUtc;
        #endregion Declare DealDetails

        //ReferencData
        #region Declare ReferenceDate
        private readonly DealInsertTransactionReferenceData _referenceData = new DealInsertTransactionReferenceData();
        private String _comment;

        //GroupField
        private readonly GroupFieldsType _groupField = new GroupFieldsType();

        private String _groupField1;
        private String _groupField2;
        private String _groupField3;
        private String _externalId;
        private String _externalSource;
        private String _ticketNumber;
        private float _riskValue;
        private String _customCompanyId;
        private String _customCompanyName;
        #endregion Declare ReferenceDate

        //CustomProperties
        #region Declare CustomProperties
        private readonly DealInsertTransactionPropertyGroup _customPropertyGroup = new DealInsertTransactionPropertyGroup();
        private readonly object[] _customPropertyObjectArray = new object[1];
        private readonly DealInsertTransactionPropertyGroup[] _customPropertyGroupArray = new DealInsertTransactionPropertyGroup[1];
        private String _customPropertyGroupName;
        private readonly DealInsertTransactionPropertyGroupStringProperty _propertyGroupStringProperty = new DealInsertTransactionPropertyGroupStringProperty();
        private String _customPropertyStringName;
        private String _customPropertyStringValue;
        private readonly DealInsertTransactionPropertyGroupDateProperty _propertyGroupDateProperty = new DealInsertTransactionPropertyGroupDateProperty();
        private String _customPropertyDateName;
        private DateTime _customPropertyDateValue;
        private readonly DealInsertTransactionPropertyGroupBooleanProperty _propertyGroupBooleanProperty = new DealInsertTransactionPropertyGroupBooleanProperty();
        private String _customPropertyBoolName;
        private Boolean _customPropertyBoolValue;
        #endregion Declare CustomProperties

        //InstrumentData
        #region Declare InstrumentData
        public TimezoneType _Timezone;
        public bool _TimezoneSpecified;
        public ExecutionVenueType _ExecutionVenue;
        public string _PriceBasis;
        public string _LoadProfile;
        public DateTime _FromDate;
        public DateTime _ToDate;
        public DateTime _transferDate;
        public DateTime _settlementDate;
        public object _Item;
        public FinancialType Financial = new FinancialType();
        public PhysicalTypeBalanceArea Physical = new PhysicalTypeBalanceArea();
        public string _PhysicalDeliveryAreaName;
        public string _period;
        public string _certificateType;
        public string _fromCountry;
        public string _toCountry;
        public string _country;
        #endregion Declare InstrumentData

        //SettlementData
        #region Declare SettelmentData
        public double _Quantity;
        public QuantityUnitType _QuantityUnit;
        public QuantityUnitTypeGas _QuantityUnitGas;
        public QuantityUnitTypeOil _QuantityUnitOil;
        
        public double _Price;
        public CurrencyType _Currency;
        public PriceVolumeUnitType _PriceVolumeUnit;
        public PriceVolumeUnitTypeGasExtended _PriceVolumeUnitGasExtended;
        public PriceVolumeUnitTypeCoal _PriceVolumeUnitTypeCoal;
        public PriceVolumeUnitTypeOil _PriceVolumeUnitTypeOil;
        private PriceVolumeUnitTypeEmission _priceVolumeUnitTypeEmission;
        public bool _PriceVolumeUnitSpecified;
        public CurrencySourceType _CurrencySource;
        public ClearingType _Clearing;
        public CurrencyType _ClearingCurrency;
        public double _ClearingFee;
        public bool _ClearingFeeSpecified;
        public double _BrokerTradingFee;
        public bool _BrokerTradingFeeSpecified;
        public CurrencyType _BrokerCurrency;
        public double _BrokerFee;
        public bool _BrokerFeeSpecified;
        public CurrencyType _BrokerFeeCurrency;
        public bool _BrokerFeeCurrencySpecified;
        public double _TradingFee;
        public bool _TradingFeeSpecified;
        public CurrencyType _TradingFeeCurrency;
        public bool _TradingFeeCurrencySpecified;
        public double _CommissionFee;
        public bool _CommissionFeeSpecified;
        public CurrencyType _CommissionFeeCurrency;
        public bool _CommissionFeeCurrencySpecified;
        public string _Broker;
        public string _SettlementRuleName;
        public bool _AuthorisationConfirmed;
        #endregion Declare SettelmentData

        public ElvizXmlBase()
        {
            _insert.MetaData = _metaData;
            _insert.Item = Transaction;
            Transaction.Portfolios = _portfolios;
            Transaction.DealDetails = _dealDetails;
            Transaction.ReferenceData = _referenceData;
            Transaction.ReferenceData.Item = _groupField;
        }

        //MetaData
        #region GetSet MetaData
        public String AuthenticationToken
        {
            get { return _authenticationToken; }
            set { _authenticationToken = value; _insert.MetaData.AuthenticationToken = value; }
        }
        public String MessageId
        {
            get { return _messageId; }
            set { _messageId = value; _insert.MetaData.MessageId = value; }
        }
        #endregion GetSet MetaData

        //Transaction
        #region GetSet Transaction
        public TransactionTypeType TransactionType
        {
            get { return _transactionType; }
            set { _transactionType = value; Transaction.TransactionType = value; }
        }

        public DealInsertTransactionDealType DealType
        {
            get { return _dealType; }
            set { _dealType = value; Transaction.DealType = value; }
        }
        #endregion GetSet Transaction

        //Portfolio
        #region GetSet Portfolio
        public BuySellType BuySell
        {
            get { return _buySell; }
            set { _buySell = value; Transaction.Portfolios.BuySell = value; }
        }

        public String CounterpartyPortfolio
        {
            get { return _counterpartyPortfolio; }
            set { _counterpartyPortfolio = value; Transaction.Portfolios.CounterpartyPortfolio = value; }
        }

        public String Portfolio
        {
            get { return _portfolio; }
            set { _portfolio = value; Transaction.Portfolios.Portfolio = value; }
        }
        #endregion GetSet Portfolio

        //DealDetails
        #region GetSet DealDetails

        public StatusType Status
        {
            get { return _status; }
            set { _status = value; Transaction.DealDetails.Status = value; }
        }

        public String Trader
        {
            get { return _trader; }
            set { _trader = value; Transaction.DealDetails.Trader = value; }
        }

        public DateTime TradeDate
        {
            get { return _tradeDate; }
            set { _tradeDate = value; Transaction.DealDetails.TradeDate = value; }
        }

        public Boolean ConfirmedByBroker
        {
            get { return _confirmedByBroker; }
            set { _confirmedByBroker = value; Transaction.DealDetails.ConfirmedByBroker = value; Transaction.DealDetails.ConfirmedByBrokerSpecified = true; }
        }

        public Boolean ConfirmedByCounterparty
        {
            get { return _confirmedByCounterparty; }
            set { _confirmedByCounterparty = value; Transaction.DealDetails.ConfirmedByCounterparty = value; Transaction.DealDetails.ConfirmedByCounterpartySpecified = true; }
        }

        public Boolean Authorised
        {
            get { return _authorised; }
            set { _authorised = value; Transaction.DealDetails.Authorised = value; Transaction.DealDetails.AuditedSpecified = true; }
        }

        public Boolean Paid
        {
            get { return _paid; }
            set { _paid = value; Transaction.DealDetails.Paid = value; Transaction.DealDetails.PaidSpecified = true; }
        }

        public DateTime TimeSpampClearedUtc
        {
            get { return _timeSpampClearedUtc; }
            set { _timeSpampClearedUtc = value; Transaction.DealDetails.TimeStampClearedUTC = value; Transaction.DealDetails.TimeStampClearedUTCSpecified = true; }
        }

        public DateTime TimeSpampConfirmedBrokerUtc
        {
            get { return _timeSpampConfirmedBrokerUtc; }
            set { _timeSpampConfirmedBrokerUtc = value; Transaction.DealDetails.TimeStampConfirmationBrokerUTC = value; Transaction.DealDetails.TimeStampConfirmationBrokerUTCSpecified = true; }
        }

        public DateTime TimeSpampConfirmedCounterPartyUtc
        {
            get { return _timeSpampConfirmedCounterPartyUtc; }
            set { _timeSpampConfirmedCounterPartyUtc = value; Transaction.DealDetails.TimeStampConfirmationCounterPartyUTC = value; Transaction.DealDetails.TimeStampConfirmationCounterPartyUTCSpecified = true; }
        }
        #endregion GetSet DealDetails

        //ReferencData
        #region GetSet ReferenceDate

        public String Comment
        {
            get { return _comment; }
            set { _comment = value; Transaction.ReferenceData.Comment = value; }
        }

        public String GroupField1
        {
            get { return _groupField1; }
            set { _groupField1 = value; _groupField.GroupField1 = value; }
        }

        public String GroupField2
        {
            get { return _groupField2; }
            set { _groupField2 = value; _groupField.GroupField2 = value; }
        }

        public String GroupField3
        {
            get { return _groupField3; }
            set { _groupField3 = value; _groupField.GroupField3 = value; }
        }

        public String ExternalId
        {
            get { return _externalId; }
            set { _externalId = value; Transaction.ReferenceData.ExternalId = value; }
        }

        public String ExternalSource
        {
            get { return _externalSource; }
            set { _externalSource = value; Transaction.ReferenceData.ExternalSource = value; }
        }

        public String TicketNumber
        {
            get { return _ticketNumber; }
            set { _ticketNumber = value; Transaction.ReferenceData.TicketNumber = value; }
        }

        public float RiskValue
        {
            get { return _riskValue; }
            set { _riskValue = value; Transaction.ReferenceData.RiskValue = value; }
        }

        public String CustomCompanyId
        {
            get { return _customCompanyId; }
            set { _customCompanyId = value; Transaction.ReferenceData.CustomCompanyId = value; }
        }

        public String CustomCompanyName
        {
            get { return _customCompanyName; }
            set { _customCompanyName = value; Transaction.ReferenceData.CustomCompanyName = value; }
        }
        #endregion GetSet ReferenceDate
    
        //CustomProperties
        #region GetSet CustomProperties
        public String CustomPropertyGroupName
        {
            get { return _customPropertyGroupName; }
            set
            {
                _customPropertyGroupName = value; _customPropertyGroup.name = value;
            }
        }

        public String CustomPropertyStringName
        {
            get { return _customPropertyStringName; }
            set { _customPropertyStringName = value; _propertyGroupStringProperty.name = value; }
        }

        public String CustomPropertyStringValue
        {
            get { return _customPropertyStringValue; }
            set
            {
                _customPropertyStringValue = value;
                _propertyGroupStringProperty.value = value;
            }
        }

        public void CreateGroup(string groupName)
        {
            if (Transaction.CustomProperties == null)
            {
                Transaction.CustomProperties = new DealInsertTransactionPropertyGroup[0];
            }

            var currentItems = Transaction.CustomProperties.ToList();

            if (currentItems.Any(x=> x != null) && currentItems.Any(x => x.name == groupName))
            {
                throw new Exception($"Group with this name already exists. Method: {MethodBase.GetCurrentMethod()}");
            }

            currentItems.Add(new DealInsertTransactionPropertyGroup {name = groupName, Items = null});

            Transaction.CustomProperties = currentItems.ToArray();
        }
        public void AddStringPropertyToGroup(string groupName, DealInsertTransactionPropertyGroupStringProperty stringProperty)
        {
            List<DealInsertTransactionPropertyGroup> allCustomPropertyGroups = Transaction.CustomProperties.ToList();
            var currentPropertyGroup = allCustomPropertyGroups.FirstOrDefault(x => x.name == groupName);
            if (currentPropertyGroup == null)
            {
                throw new CustomGroupNotFoundException($"Group name {groupName} was not fround. Create a group, with the groupname: [{groupName}] first. {MethodBase.GetCurrentMethod()}" );
            }

            if (currentPropertyGroup.Items == null)
            {
                currentPropertyGroup.Items = new object[1] {stringProperty};
            }
            else
            {
                // Check if already exists
                if (
                    currentPropertyGroup.Items.OfType<DealInsertTransactionPropertyGroupStringProperty>()
                        .Any(currentItem => currentItem.name == stringProperty.name))
                {
                    throw new DuplicateStringPropertyException(
                        $"The property {stringProperty.name} already exists. This could potentially overwrite a values. {MethodBase.GetCurrentMethod()}");
                }
                

                var existingItems = currentPropertyGroup.Items.ToList();
                existingItems.Add(stringProperty);
                currentPropertyGroup.Items = existingItems.ToArray();
            }


           
            //_customPropertyObjectArray[0] = _propertyGroupStringProperty;
            //_customPropertyGroup.Items = _customPropertyObjectArray;
            //_customPropertyGroupArray[0] = _customPropertyGroup;
            //Transaction.CustomProperties = _customPropertyGroupArray;
        }

        public String CustomPropertyDateName
        {
            get { return _customPropertyDateName; }
            set { _customPropertyDateName = value; _propertyGroupDateProperty.name = value; }
        }

        public DateTime CustomPropertyDateValue
        {
            get { return _customPropertyDateValue; }
            set { _customPropertyDateValue = value; _propertyGroupDateProperty.value = value; _customPropertyObjectArray[1] = _propertyGroupDateProperty; }
        }

        public String CustomPropertyBoolName
        {
            get { return _customPropertyBoolName; }
            set { _customPropertyBoolName = value; _propertyGroupBooleanProperty.name = value; }
        }

        public Boolean CustomPropertyBoolValue
        {
            get { return _customPropertyBoolValue; }
            set { _customPropertyBoolValue = value; _propertyGroupBooleanProperty.value = value; _customPropertyObjectArray[2] = _propertyGroupBooleanProperty; }
        }
        #endregion GetSet CustomProperties

        //InstrumentData

        #region GetSet InstrimentData
        public virtual string Country { get { return _country; } set { _country = value; } }

        public virtual FinancialType FinancialType { get { return Financial; } set { Financial = value; } }

        public virtual TimezoneType Timezone
        {
            get { return _Timezone; }
            set { _Timezone = value; }
        }
        public virtual string CertificateType
        {
            get { return _certificateType; }
            set { _certificateType = value; }
        }

        public virtual string Period
        {
            get { return _period; }
            set { _period = value; }
        }
        public virtual DateTime TransferDate
        {
            get { return _transferDate; }
            set { _transferDate = value; }
        }
        public virtual bool TimezoneSpecified
        {
            get { return _TimezoneSpecified; }
            set { _TimezoneSpecified = value; }
        }

        public virtual ExecutionVenueType ExecutionVenue
        {
            get { return _ExecutionVenue; }
            set { _ExecutionVenue = value; }
        }

        public virtual string PriceBasis
        {
            get { return _PriceBasis; }
            set { _PriceBasis = value; }
        }

        public virtual string LoadProfile
        {
            get { return _LoadProfile; }
            set
            {
                _LoadProfile = value;
            }
        }

        public virtual DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }

        public virtual DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        public virtual DateTime SettlementDate {
            get { return _settlementDate; } 
            set { _settlementDate = value; } }

        public virtual object Item
        {
            get { return _Item; }
            set { _Item = value; }
        }

        public virtual string PhysicalDeliveryAreaName
        {
            get { return _PhysicalDeliveryAreaName; }
            set { _PhysicalDeliveryAreaName = value; }
        }

        public virtual string FromCountry
        {
            get { return _fromCountry; }
            set { _fromCountry = value; }
        }

        public virtual string ToCountry
        {
            get { return _toCountry; }
            set { _toCountry = value; }
        }
        #endregion GetSet InstrimentData

        //SettlementData
        #region GetSet SettelmentData
        public virtual double Quantity
        {
            get { return _Quantity; }
            set { _Quantity = value; }
        }

        public virtual QuantityUnitType QuantityUnit
        {
            get { return _QuantityUnit; }
            set { _QuantityUnit = value; }
        }

        public virtual QuantityUnitTypeOil QuantityUnitOil
        {
            get { return _QuantityUnitOil; }
            set { _QuantityUnitOil = value; }
        }

        public virtual QuantityUnitTypeGas QuantityUnitGas
        {
            get { return _QuantityUnitGas; }
            set { _QuantityUnitGas = value; }
        }

        public virtual double Price
        {
            get { return _Price; }
            set { _Price = value; }
        }

        public virtual CurrencyType Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }

        public virtual PriceVolumeUnitType PriceVolumeUnit
        {
            get { return _PriceVolumeUnit; }
            set { _PriceVolumeUnit = value; }
        }
        public virtual PriceVolumeUnitTypeEmission PriceVolumeUnitTypeEmission
        {
            set
            {
                _priceVolumeUnitTypeEmission = value;
            }
        }
        public virtual PriceVolumeUnitTypeOil PriceVolumeUnitTypeOil
        {
            get
            {
                
                return _PriceVolumeUnitTypeOil;
            }
            set { _PriceVolumeUnitTypeOil = value; }
        }

        public virtual PriceVolumeUnitTypeGasExtended PriceVolumeUnitGasExtended
        {
            get { return _PriceVolumeUnitGasExtended; }
            set { _PriceVolumeUnitGasExtended = value; }
        }

        public virtual PriceVolumeUnitTypeCoal PriceVolumeUnitTypeCoal
        {
            get { return _PriceVolumeUnitTypeCoal; }
            set { _PriceVolumeUnitTypeCoal = value; }
        }

        public virtual CurrencySourceType CurrencySource
        {
            get { return _CurrencySource; }
            set { _CurrencySource = value; }
        }

        public virtual ClearingType Clearing
        {
            get { return _Clearing; }
            set { _Clearing = value; }
        }

        public virtual CurrencyType ClearingCurrency
        {
            get { return _ClearingCurrency; }
            set { _ClearingCurrency = value; }
        }

        public virtual double ClearingFee
        {
            get { return _ClearingFee; }
            set { _ClearingFee = value; }
        }

        public virtual bool ClearingFeeSpecified
        {
            get { return _ClearingFeeSpecified; }
            set { _ClearingFeeSpecified = value; }
        }

        public virtual double BrokerTradingFee
        {
            get { return _BrokerTradingFee; }
            set { _BrokerTradingFee = value; }
        }

        public virtual bool BrokerTradingFeeSpecified
        {
            get { return _BrokerTradingFeeSpecified; }
            set { _BrokerTradingFeeSpecified = value; }
        }

        public virtual CurrencyType BrokerCurrency
        {
            get { return _BrokerCurrency; }
            set { _BrokerCurrency = value; }
        }

        public virtual double BrokerFee
        {
            get { return _BrokerFee; }
            set { _BrokerFee = value; }
        }

        public virtual bool BrokerFeeSpecified
        {
            get { return _BrokerFeeSpecified; }
            set { _BrokerFeeSpecified = value; }
        }

        public virtual CurrencyType BrokerFeeCurrency
        {
            get { return _BrokerFeeCurrency; }
            set { _BrokerFeeCurrency = value; }
        }

        public virtual bool BrokerFeeCurrencySpecified
        {
            get { return _BrokerFeeCurrencySpecified; }
            set { _BrokerFeeCurrencySpecified = value; }
        }

        public virtual double TradingFee
        {
            get { return _TradingFee; }
            set { _TradingFee = value; }
        }

        public virtual bool TradingFeeSpecified
        {
            get { return _TradingFeeSpecified; }
            set { _TradingFeeSpecified = value; }
        }

        public virtual CurrencyType TradingFeeCurrency
        {
            get { return _TradingFeeCurrency; }
            set { _TradingFeeCurrency = value; }
        }

        public virtual bool TradingFeeCurrencySpecified
        {
            get { return _TradingFeeCurrencySpecified; }
            set { _TradingFeeCurrencySpecified = value; }
        }

        public virtual double CommissionFee
        {
            get { return _CommissionFee; }
            set { _CommissionFee = value; }
        }

        public virtual bool CommissionFeeSpecified
        {
            get { return _CommissionFeeSpecified; }
            set { _CommissionFeeSpecified = value; }
        }

        public virtual CurrencyType CommissionFeeCurrency
        {
            get { return _CommissionFeeCurrency; }
            set { _CommissionFeeCurrency = value; }
        }

        public virtual bool CommissionFeeCurrencySpecified
        {
            get { return _CommissionFeeCurrencySpecified; }
            set { _CommissionFeeCurrencySpecified = value; }
        }

        public virtual string Broker
        {
            get { return _Broker; }
            set { _Broker = value; }
        }

        public virtual string SettlementRuleName
        {
            get { return _SettlementRuleName; }
            set { _SettlementRuleName = value; }
        }

        public virtual bool AuthorisationConfirmed
        {
            get { return _AuthorisationConfirmed; }
            set { _AuthorisationConfirmed = value; }
        }
        #endregion GetSet SettelmentData
    }

    public class DuplicateStringPropertyException : Exception
    {
        public DuplicateStringPropertyException(string message) : base(message)
        {
            
        }
    }

    public class CustomGroupNotFoundException : Exception
    {
        public CustomGroupNotFoundException(string message) : base(message)
        {
            
        }
    }
}
