﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public interface IElvizSerializerFactory
    {
        IXmlSerializer Get(DealTypeEnum dealType);
        void Add(DealTypeEnum dealType, IXmlSerializer serializer);

    }
    public class ElvizSerializerFactory : IElvizSerializerFactory
    {
        private Dictionary<DealTypeEnum, IXmlSerializer> _xmlSerializers;
        public ElvizSerializerFactory()
        {
            _xmlSerializers = new Dictionary<DealTypeEnum, IXmlSerializer>();
        }
        
        public IXmlSerializer Get(DealTypeEnum dealType)
        {
            return _xmlSerializers[dealType];
        }

        public void Add(DealTypeEnum dealType, IXmlSerializer serializer)
        {
            _xmlSerializers.Add(dealType, serializer);
        }
    }
}
