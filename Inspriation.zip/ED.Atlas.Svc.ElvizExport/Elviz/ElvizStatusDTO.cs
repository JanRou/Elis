﻿using System;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class ElvizStatusDto
    {
        public Guid Guid { get; set; }

        public string Message { get; set; }
    }
}
