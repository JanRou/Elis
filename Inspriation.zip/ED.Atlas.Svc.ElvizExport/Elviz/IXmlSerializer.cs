﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Deals;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public interface IXmlSerializer
    {
        string Serialize(IElectricitySpotDeal deal);
    }
}
