﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using ED.Atlas.Svc.ElvizExport.Deals;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class SpotDealSerializer : IXmlSerializer
    {
        public string Serialize(IElectricitySpotDeal deal)
        {

            DealInsert dealInsert = CreateDealInsert(deal);
            return Serialization.Serialize<DealInsert>(dealInsert);
        }

        public DealInsert CreateDealInsert(IElectricitySpotDeal deal)
        {
            DealInsert ret = new DealInsert();
            ret.MetaData = CreateMetadata(deal);
            ret.Transaction = CreateTransaction(deal);
            return ret;
        }

        public DealInsertMetaData CreateMetadata(IElectricitySpotDeal deal)
        {
            DealInsertMetaData ret = new DealInsertMetaData();
            ret.TimezoneSpecified = true;
            ret.Timezone = TimezoneType.CET;
            return ret;
        }
        public DealInsertTransaction CreateTransaction(IElectricitySpotDeal deal)
        {
            DealInsertTransaction ret = new DealInsertTransaction();
            ret.TransactionType = TransactionTypeType.Automatic;
            ret.DealType = DealInsertTransactionDealType.ElectricitySpot;
            ret.Portfolios = CreatPortefolios(deal);
            ret.Spot = CreateSpot(deal);
            ret.DealDetails = CreateDealDetails(deal);
            ret.ReferenceData = CreateRefereneData(deal);
            return ret;
        }

        public DealInsertTransactionPortfolios CreatPortefolios(IElectricitySpotDeal deal)
        {
            DealInsertTransactionPortfolios ret = new DealInsertTransactionPortfolios();
            ret.CounterpartyPortfolio = deal.CounterPartyPortefolio;
            ret.BuySell = deal.Direction == "B" ? BuySellType.Buy : BuySellType.Sell;
            ret.Portfolio = deal.Portefolio;
            return ret;
        }

        private DealInsertTransactionReferenceData CreateRefereneData(IElectricitySpotDeal deal)
        {
            DealInsertTransactionReferenceData ret = new DealInsertTransactionReferenceData();
            ret.ExternalId = deal.GUID; // 10 last chars of GUID
            ret.ExternalSource = "XMLFileImport";
            ret.AtlasGroupFields = CreateGroupFieds(deal);
            return ret;
        }

        public GroupFieldsType CreateGroupFieds(IElectricitySpotDeal deal)
        {
            GroupFieldsType ret = new GroupFieldsType();
            ret.GroupField1 = deal.GUID;
            return ret;
        }

        public DealInsertTransactionDealDetails CreateDealDetails(IElectricitySpotDeal deal)
        {
            DealInsertTransactionDealDetails ret = new DealInsertTransactionDealDetails();
            ret.TradeDate = deal.TradeTimeUtc.ToLocalTime().Date;
            ret.Trader = "CK";  // TODO has to configurable
            return ret;
        }

        public DealInsertTransactionElectricitySpot CreateSpot(IElectricitySpotDeal deal)
        {
            DealInsertTransactionElectricitySpot ret = new DealInsertTransactionElectricitySpot();
            ret.InstrumentData = CreateInstrumentData(deal);
            ret.SettlementData = CreateSettlementData(deal);
            return ret;
        }

        public DealInsertTransactionElectricitySpotInstrumentData CreateInstrumentData(IElectricitySpotDeal deal)
        {
            DealInsertTransactionElectricitySpotInstrumentData ret = new DealInsertTransactionElectricitySpotInstrumentData();
            ret.ExecutionVenue = deal.ExecutionVenue != null
                ? (ExecutionVenueType) Enum.Parse(typeof(ExecutionVenueType), deal.ExecutionVenue)
                : ExecutionVenueType.None;

            ret.PriceBasis = deal.PriceBasis;
            ret.Date = deal.BeginDateTimeUtc.ToLocalTime().Date; // Time is CET
            ret.TimezoneSpecified = true;
            ret.Timezone = TimezoneType.CET;
            ret.PhysicalBalanceArea = CreatePhysicalBalanceArea(deal);
            return ret;
        }

        public PhysicalTypeBalanceArea CreatePhysicalBalanceArea(IElectricitySpotDeal deal)
        {
            PhysicalTypeBalanceArea ret = new PhysicalTypeBalanceArea();
            ret.DeliveryArea = new BalanceAreaType() { AreaName = "ENBW"};
            return ret;
        }

        public DealInsertTransactionElectricitySpotSettlementData CreateSettlementData(IElectricitySpotDeal deal)
        {
            DealInsertTransactionElectricitySpotSettlementData ret = new DealInsertTransactionElectricitySpotSettlementData();
            ret.SpotHourInformation = CreateSpotHourInformation(deal);
            ret.TradingFeeSpecified = false;
            ret.BrokerFeeSpecified = false;
            ret.BrokerFeeCurrencySpecified = false;
            ret.BrokerTradingFeeSpecified = false;
            ret.ClearingFeeSpecified = false;
            ret.CommissionFeeCurrencySpecified = false;
            ret.CommissionFeeSpecified = false;
            ret.PriceVolumeUnitSpecified = false;
            ret.TradingFeeCurrencySpecified = false;
            ret.QuantityUnit = (QuantityUnitType) Enum.Parse( typeof(QuantityUnitType),deal.QuantityUnit); // default is "MW"
            ret.Currency = (CurrencyType) Enum.Parse(typeof(CurrencyType), deal.PriceCurrency);
            ret.Clearing = ClearingType.Electronic;
            ret.ClearingCurrency = ret.Currency;
            ret.BrokerCurrency = ret.Currency;
            ret.CurrencySource = deal.ExecutionVenue?.ToLower() == "nordpool" ? CurrencySourceType.NordPool : CurrencySourceType.ECB;
            return ret;
        }

        public DealInsertTransactionElectricitySpotSettlementDataSpotHourInformation CreateSpotHourInformation(IElectricitySpotDeal deal)
        {
            DealInsertTransactionElectricitySpotSettlementDataSpotHourInformation ret = new DealInsertTransactionElectricitySpotSettlementDataSpotHourInformation();
            ret.TimeSeriesDetail = CreateSpotHours(deal);
            return ret;
        }

        public TimeSeriesDetailType[] CreateSpotHours(IElectricitySpotDeal deal)
        {
            List<TimeSeriesDetailType> ret = new List<TimeSeriesDetailType>();
            DateTime startUtc = GetStartUtc(deal);
            int quantityDivisor = GetQuantityDivisor(deal);
            for (int h = 0; h < GetHoursOfTheDay(startUtc); h++)
            {
                TimeSeriesDetailType tsd = CreateTimeSeriesDetailType(startUtc, h);
                if (IsHourInRange(deal, startUtc, h))
                {
                    tsd = SetTimeSeriesDetailType(deal, quantityDivisor, tsd);
                }
                ret.Add(tsd);
            }
            return ret.ToArray();
        }

        public bool IsHourInRange(IElectricitySpotDeal deal, DateTime startUtc, int h)
        {
            // Check that the period startUtc.AddHours(h) <-> startUtc.AddHours(h+1) overlaps the deal period
            return ( startUtc.AddHours(h) < deal.EndDateTimeUtc ) &&  ( deal.BeginDateTimeUtc < startUtc.AddHours(h+1) );
        }

        public TimeSeriesDetailType CreateTimeSeriesDetailType(DateTime startUtc, int h)
        {
            TimeSeriesDetailType tsd = new TimeSeriesDetailType()
            {
                   DateTime = startUtc.AddHours(h).ToLocalTime()
                ,   Price = 0.0
                ,   Volume = 0.0
            };
            return tsd;
        }


        public TimeSeriesDetailType SetTimeSeriesDetailType(IElectricitySpotDeal deal, int quantityDivisor, TimeSeriesDetailType tsd)
        {
            tsd.Price = (double) (deal.Price ?? 0.0m);
            tsd.Volume = (double) (deal.Quantity/quantityDivisor ?? 0.0m);
            return tsd;
        }

        public int GetHoursOfTheDay(DateTime startUtc)
        {
            int ret = 24;
            ret -= IsWinterToSummerTimeShift(startUtc) ? 1 : 0; // subtract one hour
            ret += IsSummerToWinterTimeShift(startUtc) ? 1 : 0; // add one our
            return ret;
        }
        public bool IsSummerToWinterTimeShift(DateTime startUtc)
        {
            DateTime dt = startUtc.ToLocalTime();
            return      (dt.Month == 10)
                   &&   (dt.DayOfWeek == DayOfWeek.Sunday)
                   &&   (dt.AddDays(7).Month == 11);
        }

        public bool IsWinterToSummerTimeShift(DateTime startUtc)
        {
            DateTime dt = startUtc.ToLocalTime();
            return      (dt.Month == 3)
                   &&   (dt.DayOfWeek == DayOfWeek.Sunday)
                   &&   (dt.AddDays(7).Month == 4);
        }

        private int GetQuantityDivisor(IElectricitySpotDeal deal)
        {
            int ret = 1;
            if (deal.DayLoadProfile == null)
            {
                //Quarter => ret = 4, Half hour => ret =2
                ret = 60 / Convert.ToInt32((deal.EndDateTimeUtc - deal.BeginDateTimeUtc).TotalMinutes);
            }
            return ret;
        }

        public DateTime GetStartUtc(IElectricitySpotDeal deal)
        {
            DateTime dt = deal.BeginDateTimeUtc.ToLocalTime().Date;
            return dt.ToUniversalTime(); // Summer 22:00 the day before, winter 23:00 the day before
        }
    }

    public partial class DealInsert
    {
        [XmlIgnore] // Ignore this attribute in serialzation
        public DealInsertTransaction Transaction
        {
            get { return (DealInsertTransaction) Item; }
            set { Item = value; }
        }
    }


    public partial class DealInsertTransaction
    {
        [XmlIgnore]
        public DealInsertTransactionElectricitySpot Spot
        {
            get { return (DealInsertTransactionElectricitySpot) Item; }
            set { Item = value; }
        }
    }

    public partial class DealInsertTransactionReferenceData
    {
        [XmlIgnore]
        public GroupFieldsType AtlasGroupFields
        {
            get { return Item as GroupFieldsType; }
            set { Item = value; }
        }

        [XmlIgnore]
        public string DealGroup
        {
            get { return Item as string; }
            set { Item = value; }
        }
    }

    public partial class DealInsertTransactionElectricitySpotInstrumentData
    {
        [XmlIgnore]
        public PhysicalTypeBalanceArea PhysicalBalanceArea
        {
            get { return (PhysicalTypeBalanceArea) Item; }
            set { Item = value; }
        }
    }

}
