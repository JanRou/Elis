﻿using System;

namespace ED.Atlas.Svc.ElvizExport.Elviz
{
    public class GasForwardXml: ElvizXmlBase
    {
        readonly DealInsertTransactionGasForward _gasForward = new DealInsertTransactionGasForward();
        readonly DealInsertTransactionGasForwardInstrumentData _instrumentData = new DealInsertTransactionGasForwardInstrumentData();
        readonly DealInsertTransactionGasForwardSettlementData _settlementData = new DealInsertTransactionGasForwardSettlementData();

        public GasForwardXml()
        {
            _gasForward.InstrumentData = _instrumentData;
            _gasForward.SettlementData = _settlementData;
            Transaction.Item = _gasForward;

            DealType = DealInsertTransactionDealType.GasForward;
            TransactionType = TransactionTypeType.Automatic;

            _instrumentData.TimezoneSpecified = true;
            _instrumentData.Timezone = TimezoneType.CET;
        }

        //InstrumentData

        #region GetSet InstrumentData
        public override TimezoneType Timezone
        {
            set { _Timezone = value; _instrumentData.Timezone = value; TimezoneSpecified = true; }
        }

        public override bool TimezoneSpecified
        {
            set { _TimezoneSpecified = value; _instrumentData.TimezoneSpecified = value; }
        }

        public override ExecutionVenueType ExecutionVenue
        {
            set { _ExecutionVenue = value; _instrumentData.ExecutionVenue = value; }
        }

        public override string PriceBasis
        {
            set { _PriceBasis = value; _instrumentData.PriceBasis = value; }
        }

        public override string LoadProfile
        {
            set
            {
                if (string.Equals(value, "OffPeak", StringComparison.InvariantCultureIgnoreCase))
                {
                    _LoadProfile = "Off peak";
                    _instrumentData.LoadProfile = _LoadProfile;
                }
                else
                {
                    _LoadProfile = value;
                    _instrumentData.LoadProfile = value;
                }
            }
        }

        public override DateTime FromDate
        {
            set { _FromDate = value; _instrumentData.FromDate = value; }
        }

        public override DateTime ToDate
        {
            set { _ToDate = value; _instrumentData.ToDate = value; }
        }

        public override object Item
        {
            set { _Item = value; _instrumentData.Item = value; }
        }

        public override string PhysicalDeliveryAreaName
        {
            get { return _PhysicalDeliveryAreaName; }
            set
            {
                _PhysicalDeliveryAreaName = value;
                Physical.DeliveryArea = new BalanceAreaType { AreaName = value };
                _instrumentData.Item = Physical;
            }
        }
        #endregion GetSet InstrumentData

        //SettlementData

        #region GetSet SettlementData        
        public override double Quantity
        {
            set { _Quantity = value; _settlementData.Quantity = value; }
        }

        public override QuantityUnitTypeGas QuantityUnitGas
        {
            set { base.QuantityUnitGas = value; _settlementData.QuantityUnit = value; }
        }

        public override double Price
        {
            set { _Price = value; _settlementData.Price = value; }
        }

        public override CurrencyType Currency
        {
            set { _Currency = value; _settlementData.Currency = value; }
        }

        public override PriceVolumeUnitTypeGasExtended PriceVolumeUnitGasExtended

        {
            set { _PriceVolumeUnitGasExtended = value; _settlementData.PriceVolumeUnit = value; }
        }

        public override CurrencySourceType CurrencySource
        {
            set { _CurrencySource = value; _settlementData.CurrencySource = value; }
        }

        public override ClearingType Clearing
        {
            set { _Clearing = value; _settlementData.Clearing = value; }
        }

        public override CurrencyType ClearingCurrency
        {
            set { _ClearingCurrency = value; _settlementData.ClearingCurrency = value; }
        }

        public override double ClearingFee
        {
            set { _ClearingFee = value; _settlementData.ClearingFee = value; ClearingFeeSpecified = true; }
        }

        public override bool ClearingFeeSpecified
        {
            set { _ClearingFeeSpecified = value; _settlementData.ClearingFeeSpecified = value; }
        }

        public override double BrokerTradingFee
        {
            set { _BrokerTradingFee = value; _settlementData.BrokerTradingFee = value; BrokerTradingFeeSpecified = true; }
        }

        public override bool BrokerTradingFeeSpecified
        {
            set { _BrokerTradingFeeSpecified = value; _settlementData.BrokerTradingFeeSpecified = value; }
        }

        public override CurrencyType BrokerCurrency
        {
            set { _BrokerCurrency = value; _settlementData.BrokerCurrency = value; }
        }

        public override double BrokerFee
        {
            set { _BrokerFee = value; _settlementData.BrokerFee = value; BrokerFeeSpecified = true; }
        }

        public override bool BrokerFeeSpecified
        {
            set { _BrokerFeeSpecified = value; _settlementData.BrokerFeeSpecified = value; }
        }

        public override CurrencyType BrokerFeeCurrency
        {
            set { _BrokerFeeCurrency = value; _settlementData.BrokerFeeCurrency = value; BrokerFeeCurrencySpecified = true; }
        }

        public override bool BrokerFeeCurrencySpecified
        {
            set { _BrokerFeeCurrencySpecified = value; _settlementData.BrokerFeeCurrencySpecified = value; }
        }

        public override double TradingFee
        {
            set { _TradingFee = value; _settlementData.TradingFee = value; TradingFeeSpecified = true; }
        }

        public override bool TradingFeeSpecified
        {
            set { _TradingFeeSpecified = value; _settlementData.TradingFeeSpecified = value; }
        }

        public override CurrencyType TradingFeeCurrency
        {
            set { _TradingFeeCurrency = value; _settlementData.TradingFeeCurrency = value; TradingFeeCurrencySpecified = true; }
        }

        public override bool TradingFeeCurrencySpecified
        {
            set { _TradingFeeCurrencySpecified = value; _settlementData.TradingFeeCurrencySpecified = value; }
        }

        public override double CommissionFee
        {
            set { _CommissionFee = value; _settlementData.CommissionFee = value; CommissionFeeSpecified = true; }
        }

        public override bool CommissionFeeSpecified
        {
            set { _CommissionFeeSpecified = value; _settlementData.CommissionFeeSpecified = value; }
        }

        public override CurrencyType CommissionFeeCurrency
        {
            set { _CommissionFeeCurrency = value; _settlementData.CommissionFeeCurrency = value; CommissionFeeCurrencySpecified = true; }
        }

        public override bool CommissionFeeCurrencySpecified
        {
            set { _CommissionFeeCurrencySpecified = value; _settlementData.CommissionFeeCurrencySpecified = value; }
        }

        public override string Broker
        {
            set { _Broker = value; _settlementData.Broker = value; }
        }

        public override string SettlementRuleName
        {
            set { _SettlementRuleName = value; _settlementData.SettlementRuleName = value; }
        }

        #endregion GetSet SettelmentData
    }
}
