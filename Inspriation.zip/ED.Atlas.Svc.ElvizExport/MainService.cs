﻿using System;
using log4net;
using log4net.Core;

namespace ED.Atlas.Svc.ElvizExport
{

    public interface IMainService : IRunner
    {
    }
    public class MainService : IMainService
    {
        private readonly IWebRunner _webRunner;
        private readonly IBackendRunner _backendRunner;
        //private readonly ILoggerManager _loggerManager;

        public MainService(IWebRunner webRunner,  IBackendRunner backendRunner)
        {
            _webRunner = webRunner;
           _backendRunner = backendRunner;
            //_loggerManager = loggerManager;
                       
        }

        public void Start()
        {
            // Enable Logging
            //_loggerManager.ConfigureLog4Net();

            _backendRunner.Start();
            _webRunner.Start();
        }

        public void Stop()
        {
            _webRunner.Stop();
            _backendRunner.Stop();
        }
    }
}