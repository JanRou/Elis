﻿namespace ED.Atlas.Svc.ElvizExport.DTO
{
    public class AtlasDealDto
    {
        public string  AtlasDealGuid { get; set; }
    }
}