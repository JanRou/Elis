﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Settings;
using ED.Atlas.Svc.ElvizExport.TimeoutMonitor;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.Sagas
{

    public class IntradaySagaBuilder : ISagaBuilder
    {
        private readonly IProgramSettings _programSettings;
        private readonly int _numberofTransitions = 6; // According

        private Dictionary<TransitionEnum, ITransition> _transitions;

        public IntradaySagaBuilder(
                IElvizSerializerFactory elvizSerializerFactory
            ,   IProgramSettings programSettings
            ,   IExportTimeoutMonitor exportTimeoutMonitor
            ,   IFileHandlers fileHandlers
            ,   ISharedRestCommunication sharedRestCommunication)
        {
            _programSettings = programSettings;
            _transitions = new Dictionary<TransitionEnum, ITransition>();
            // TODO the follwoing constructions of transitions have to be constructed by the IoC container
            _transitions.Add(TransitionEnum.CreateXml
                , new CreateXmlTransition( elvizSerializerFactory, new EdLogger<CreateXmlTransition>()));
            _transitions.Add(TransitionEnum.WriteFile, new WriteFileTransition(
                _programSettings.ElvizXmlExportTemporaryPath, _programSettings.ElvizXmlExportPath, new EdLogger<WriteFileTransition>()));
            _transitions.Add(TransitionEnum.RegisterFilehandle, new RegisterFilehandleTransition(exportTimeoutMonitor));
            _transitions.Add(TransitionEnum.HandleResult
                , new ExportResultFileHandlingTransition(exportTimeoutMonitor, programSettings.ElvizXmlResultsPath));
            _transitions.Add(TransitionEnum.FinalizeFilehandling, new FinalizeTransition(
                fileHandlers, sharedRestCommunication,_programSettings.FetchAtlasDealUrl));
            _transitions.Add(TransitionEnum.ErrorTransition, new ErrorTransition(
                fileHandlers, sharedRestCommunication, _programSettings.FetchAtlasDealUrl));
        }

        public ISagaBuilder With(TransitionEnum transitionEnum, ITransition transition)
        {
            _transitions[transitionEnum] = transition;
            return this;
        }

        public ITransition Get(TransitionEnum transitionType)
        {
            return _transitions[transitionType];  // For test, throws exception when transitionType isn't added
        }

        public ISaga Build()
        {
            Saga saga = null;
            saga = new Saga();
            // Ready state
            saga.RegisterTransition(StateEnum.Ready, EventEnum.NewFile, _transitions[TransitionEnum.CreateXml]);
            saga.RegisterNextState(StateEnum.Ready, _transitions[TransitionEnum.CreateXml], StateEnum.WaitXmlCreated);
            // Wait Xml Created
            saga.RegisterTransition(StateEnum.WaitXmlCreated, EventEnum.XmlCreated,
                _transitions[TransitionEnum.WriteFile]);
            saga.RegisterTransition(StateEnum.WaitXmlCreated, EventEnum.XmlCreationError,
                _transitions[TransitionEnum.ErrorTransition]);
            saga.RegisterNextState(StateEnum.WaitXmlCreated, _transitions[TransitionEnum.WriteFile],
                StateEnum.WaitFileWritten);
            saga.RegisterNextState(StateEnum.WaitXmlCreated, _transitions[TransitionEnum.ErrorTransition],
                StateEnum.Done);
            // Wait file written
            saga.RegisterTransition(StateEnum.WaitFileWritten, EventEnum.FileWritten,
                _transitions[TransitionEnum.RegisterFilehandle]);
            saga.RegisterTransition(StateEnum.WaitFileWritten, EventEnum.FileWriteError,
                _transitions[TransitionEnum.ErrorTransition]);
            saga.RegisterNextState(StateEnum.WaitFileWritten, _transitions[TransitionEnum.RegisterFilehandle],
                StateEnum.WaitForExportResult);
            saga.RegisterNextState(StateEnum.WaitFileWritten, _transitions[TransitionEnum.ErrorTransition],
                StateEnum.Done);
            // Wait export result
            saga.RegisterTransition(StateEnum.WaitForExportResult, EventEnum.Result,
                _transitions[TransitionEnum.HandleResult]);
            saga.RegisterTransition(StateEnum.WaitForExportResult, EventEnum.Timeout,
                _transitions[TransitionEnum.ErrorTransition]);
            saga.RegisterNextState(StateEnum.WaitForExportResult, _transitions[TransitionEnum.HandleResult],
                StateEnum.WaitResultHandling);
            saga.RegisterNextState(StateEnum.WaitForExportResult, _transitions[TransitionEnum.ErrorTransition],
                StateEnum.Done);
            // Wait result handling
            saga.RegisterTransition(StateEnum.WaitResultHandling, EventEnum.OkResult,
                _transitions[TransitionEnum.FinalizeFilehandling]);
            saga.RegisterTransition(StateEnum.WaitResultHandling, EventEnum.ErrorInResult,
                _transitions[TransitionEnum.ErrorTransition]);
            saga.RegisterNextState(StateEnum.WaitResultHandling, _transitions[TransitionEnum.FinalizeFilehandling],
                StateEnum.Done);
            saga.RegisterNextState(StateEnum.WaitResultHandling, _transitions[TransitionEnum.ErrorTransition],
                StateEnum.Done);
            return saga;
        }
    }
}
