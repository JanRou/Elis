﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.Sagas
{
    public interface ISaga
    {
        ITransition GetTransition(StateEnum state, EventEnum evnt);
        StateEnum GetNextState(StateEnum state, ITransition transition);
        void RegisterTransition(StateEnum state, EventEnum evnt, ITransition transition);
        void RegisterNextState(StateEnum state, ITransition transition, StateEnum nextState);
    }
}
