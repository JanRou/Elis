﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.Sagas
{

    public class Saga : ISaga
    {
        private Dictionary<Tuple<StateEnum, EventEnum>, ITransition> _stateEvent2Handler;
        private Dictionary<Tuple<StateEnum, ITransition>, StateEnum> _stateHandler2State;

        public Saga()
        {
            _stateEvent2Handler = new Dictionary<Tuple<StateEnum, EventEnum>, ITransition>();
            _stateHandler2State = new Dictionary<Tuple<StateEnum, ITransition>, StateEnum>();
        }

        public ITransition GetTransition(StateEnum state, EventEnum evnt)
        {
            return _stateEvent2Handler.ContainsKey(Tuple.Create(state, evnt))
                ? _stateEvent2Handler[Tuple.Create(state, evnt)]
                : null;
        }

        public StateEnum GetNextState(StateEnum state, ITransition transition)
        {
            return _stateHandler2State.ContainsKey(Tuple.Create(state, transition))
                ? _stateHandler2State[Tuple.Create(state, transition)]
                : StateEnum.Undefined;
        }

        public void RegisterTransition(StateEnum state, EventEnum evnt, ITransition transition)
        {
            ;
            if (!_stateEvent2Handler.ContainsKey(Tuple.Create(state, evnt)))
            {
                // Insert new tuple as key and transition as value
                _stateEvent2Handler.Add(Tuple.Create(state, evnt), transition);
            }
            else
            {
                throw new InvalidDataException($"State, Event combination ({state}, {evnt}) already exists");
            }
        }

        public void RegisterNextState(StateEnum state, ITransition transition, StateEnum nextState)
        {
            if (!_stateHandler2State.ContainsKey(Tuple.Create(state, transition)))
            {
                _stateHandler2State.Add(Tuple.Create(state, transition), nextState);
            }
            else
            {
                throw new InvalidDataException($"State, IHandler combination ({state}, {transition}) already exists");
            }

        }
    }
}
