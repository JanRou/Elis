﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.Sagas
{
    public interface ISagaBuilder
    {
        /// <summary>
        /// For test Get returns what's set up for the transition enum.
        /// </summary>
        /// <param name="transitionType">The enum for the transition.</param>
        /// <returns>The transition registered.</returns>
        ITransition Get(TransitionEnum transitionType);
        ISagaBuilder With(TransitionEnum transitionType, ITransition transition);
        ISaga Build();
    }
}
