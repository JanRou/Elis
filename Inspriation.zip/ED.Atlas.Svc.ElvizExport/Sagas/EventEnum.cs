﻿namespace ED.Atlas.Svc.ElvizExport.Sagas
{
    public enum EventEnum
    {
            Undefined = 0            // Not defined event
        ,   NewFile = 10             // New file arrived 
        ,   XmlCreated = 20          // Xml is created
        ,   FileWritten = 30         // File is written to Elviz folder
        ,   Result = 40              // Result file found in elviz Result folder
        ,   XmlCreationError = 50    // Xml creation error
        ,   FileWriteError = 60      // Couldn't write file
        ,   Timeout = 70             // Elviz did not prduce a result file in time
        ,   OkResult = 80            // Result file says export succeeded
        ,   Done = 90                // All file handling done, not processed further
        ,   FinalizeError = 100      // Finalizeing fails, not processed further
        ,   ErrorInResult = 110      // Elviz export didn't succeed
        ,   ResultXmlReadError = 120 // Can't read result file or deserialize it
        ,   None = 9999              // The event is a no event, not processed further 
    }

}
