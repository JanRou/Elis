﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ED.Atlas.Svc.ElvizExport.Sagas
{
    public enum StateEnum
    {
            Undefined = 0
        ,   Ready = 10
        ,   WaitXmlCreated = 20
        ,   WaitFileWritten = 30
        ,   WaitForExportResult = 40
        ,   WaitResultHandling = 50
        ,   Done = 60
    }
}
