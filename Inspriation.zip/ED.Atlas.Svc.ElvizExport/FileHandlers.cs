﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.Log;

namespace ED.Atlas.Svc.ElvizExport
{
    public interface IFileHandlers
    {
        bool TryAdd(IFileHandler fh);
        void Remove(Guid fileId);
        IFileHandler Get(Guid fileId);
    }
    public class FileHandlers : IFileHandlers
    {
        private readonly IEdLog<FileHandlers> _log;
        private readonly ConcurrentDictionary<Guid, IFileHandler> _fileHandlers;

        public FileHandlers(IEdLog<FileHandlers> log)
        {
            _log = log;
            _fileHandlers = new ConcurrentDictionary<Guid, IFileHandler>(8, 100);
        }

        public bool TryAdd(IFileHandler fh)
        {
            bool result = _fileHandlers.TryAdd(fh.FileId, fh);
            if (!result)
            {
                _log.Guid = fh.FileId;
                _log.Error("Filehandle already in list of filehandlers");
            }
            return result;
        }
        public void Remove(Guid fileId)
        {
            IFileHandler ret;
            if (!_fileHandlers.TryRemove(fileId, out ret))
            {
                _log.Guid = fileId;
                _log.Error("Filehandle don't exist in list of filehandlers");
                ret = null;
            }
        }
        public IFileHandler Get(Guid fileId)
        {
            IFileHandler ret;
            if (!_fileHandlers.TryGetValue(fileId, out ret))
            {
                _log.Guid = fileId;
                _log.Error("Filehandle is not in list of filehandlers");
                ret = null;
            }
            return ret;
        }
    }
}
