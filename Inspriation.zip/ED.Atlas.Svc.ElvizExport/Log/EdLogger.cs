﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Core;
using log4net.Layout;
using log4net.Repository;
using log4net.Util;

namespace ED.Atlas.Svc.ElvizExport.Log
{
    public interface IEdLog<T> : ILog
    {
        Guid Guid { get; set; }
    }
    public class EdLogger<T> : IEdLog<T>
    {
        private ILog _log;

        public EdLogger()
        {
            _log = LogManager.GetLogger(typeof(T));
        }
        public Guid Guid { get; set; }

        public void Debug(object message)
        {
            if ( _log.IsDebugEnabled )
            {
                _log.DebugFormat($"{Guid}/~/{message}");
            }
        }

        public void Debug(object message, Exception exception)
        {
            if (_log.IsDebugEnabled)
            {
                _log.DebugFormat($"{Guid}/~/{message}", exception);
            }
        }

        public void DebugFormat(string format, params object[] args)
        {
            if (_log.IsDebugEnabled)
            {
                _log.DebugFormat($"{Guid}/~/{String.Format(format, args)}");
            }

        }

        public void DebugFormat(string format, object arg0)
        {
            if (_log.IsDebugEnabled)
            {

                _log.DebugFormat("{0}/~/{1}", Guid, String.Format(format, arg0));
            }
        }

        public void DebugFormat(string format, object arg0, object arg1)
        {
            if (_log.IsDebugEnabled)
            {
                _log.DebugFormat("{0}/~/{1}", Guid, String.Format(format, arg0, arg1));
            }
        }

        public void DebugFormat(string format, object arg0, object arg1, object arg2)
        {
            if (_log.IsDebugEnabled)
            {
                _log.DebugFormat("{0}/~/{1}", Guid, String.Format(format, arg0, arg1, arg2));
            }
        }

        public void DebugFormat(IFormatProvider provider, string format, params object[] args)
        {
            if (_log.IsDebugEnabled)
            {
                _log.DebugFormat("{0}/~/{1}", Guid, String.Format(provider, format, args));
            }
        }

        public void Info(object message)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{message}");
            }
        }

        public void Info(object message, Exception exception)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{message}", exception);
            }
        }

        public void InfoFormat(string format, params object[] args)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{String.Format(format, args)}");
            }
        }

        public void InfoFormat(string format, object arg0)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{String.Format(format, arg0)}");
            }
        }

        public void InfoFormat(string format, object arg0, object arg1)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{String.Format(format, arg0, arg1)}");
            }
        }

        public void InfoFormat(string format, object arg0, object arg1, object arg2)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{String.Format(format, arg0, arg1, arg2)}");
            }
        }

        public void InfoFormat(IFormatProvider provider, string format, params object[] args)
        {
            if ( _log.IsInfoEnabled )
            {
                _log.InfoFormat($"{Guid}/~/{String.Format(provider, format, args)}");
            }
        }

        public void Warn(object message)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{message}");
            }
        }

        public void Warn(object message, Exception exception)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{message}", exception);
            }
        }

        public void WarnFormat(string format, params object[] args)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{String.Format(format, args)}");
            }
        }

        public void WarnFormat(string format, object arg0)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{String.Format(format, arg0)}");
            }
        }

        public void WarnFormat(string format, object arg0, object arg1)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{String.Format(format, arg0, arg1)}");
            }
        }

        public void WarnFormat(string format, object arg0, object arg1, object arg2)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{String.Format(format, arg0, arg1, arg2)}");
            }
        }

        public void WarnFormat(IFormatProvider provider, string format, params object[] args)
        {
            if ( _log.IsWarnEnabled )
            {
                _log.WarnFormat($"{Guid}/~/{String.Format(provider, format, args)}");
            }
        }

        public void Error(object message)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{message}");
            }
        }

        public void Error(object message, Exception exception)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{message}", exception);
            }
        }

        public void ErrorFormat(string format, params object[] args)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{String.Format(format, args)}");
            }
        }

        public void ErrorFormat(string format, object arg0)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{String.Format(format, arg0)}");
            }
        }

        public void ErrorFormat(string format, object arg0, object arg1)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{String.Format(format, arg0, arg1)}");
            }
        }

        public void ErrorFormat(string format, object arg0, object arg1, object arg2)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{String.Format(format, arg0, arg1, arg2)}");
            }
        }

        public void ErrorFormat(IFormatProvider provider, string format, params object[] args)
        {
            if ( _log.IsErrorEnabled )
            {
                _log.ErrorFormat($"{Guid}/~/{String.Format(provider, format, args)}");
            }
        }

        public void Fatal(object message)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{message}");
            }
        }

        public void Fatal(object message, Exception exception)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{message}", exception);
            }
        }

        public void FatalFormat(string format, params object[] args)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{String.Format(format, args)}");
            }
        }

        public void FatalFormat(string format, object arg0)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{String.Format(format, arg0)}");
            }
        }

        public void FatalFormat(string format, object arg0, object arg1)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{String.Format(format, arg0, arg1)}");
            }
        }

        public void FatalFormat(string format, object arg0, object arg1, object arg2)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{String.Format(format, arg0, arg1, arg2)}");
            }
        }

        public void FatalFormat(IFormatProvider provider, string format, params object[] args)
        {
            if ( _log.IsFatalEnabled )
            {
                _log.FatalFormat($"{Guid}/~/{String.Format(provider, format, args)}");
            }
        }

        public bool IsDebugEnabled { get { return _log.IsDebugEnabled; } }
        public bool IsInfoEnabled { get { return _log.IsInfoEnabled; } }
        public bool IsWarnEnabled { get { return _log.IsWarnEnabled; } }
        public bool IsErrorEnabled { get { return _log.IsErrorEnabled; } }
        public bool IsFatalEnabled { get { return _log.IsFatalEnabled; } }
        public log4net.Core.ILogger Logger { get { return _log.Logger; } }
    }

    public class GuidAdoNetAppenderParameter : AdoNetAppenderParameter
    {
        public override void FormatValue(IDbCommand command, LoggingEvent loggingEvent)
        {
            IDbDataParameter parameter = (IDbDataParameter)command.Parameters[ParameterName];

            string guid = Split(loggingEvent.RenderedMessage);
            parameter.Value = guid;
        }
        public string Split(string rendmes)
        {
            string splitStr = "/~/";
            return rendmes.Substring(0, rendmes.IndexOf(splitStr));
        }
    }

    public class MessageAdoNetAppenderParameter : AdoNetAppenderParameter
    {
        public override void FormatValue(IDbCommand command, LoggingEvent loggingEvent)
        {
            IDbDataParameter parameter = (IDbDataParameter) command.Parameters[ParameterName];

            string guid = Split(loggingEvent.RenderedMessage);
            parameter.Value = guid;
        }
        public string Split(string rendmes)
        {
            string splitStr = "/~/";
            int start = rendmes.IndexOf(splitStr) + splitStr.Length;
            int length = rendmes.Length - start;
            return rendmes.Substring(start, length);
        }
    }

}
