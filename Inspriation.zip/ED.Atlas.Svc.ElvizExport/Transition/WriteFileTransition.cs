﻿using System;
using System.IO;
using System.Threading;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class WriteFileTransition : ITransition
    {
        private readonly string _elvizTemporaryExportPath;
        private readonly string _elvizExportPath;
        private readonly IEdLog<WriteFileTransition> _log;

        public WriteFileTransition(string elvizTemporaryExportPath, string elvizExportPath, IEdLog<WriteFileTransition> log)
        {
            _elvizTemporaryExportPath = elvizTemporaryExportPath;
            _elvizExportPath = elvizExportPath;
            _log = log;
        }

        IEvent ITransition.Execute(IFileHandler fh)
        {
            string tmpPath = _elvizTemporaryExportPath + fh.FileId + ".xml";

            var ret = new HandlerEvent {Event = EventEnum.FileWritten, Guid = fh.FileId};
            if (WriteFile(fh, ret, tmpPath))
            {
                MoveFile(ret, tmpPath, _elvizExportPath + fh.FileId + ".xml");
            }

            return ret;
        }

        public void MoveFile(HandlerEvent handlerEvent, string fromPath, string toPath)
        {
            try
            {
                File.Move(fromPath, toPath);
            }
            catch (Exception e)
            {
                handlerEvent.Event = EventEnum.FileWriteError;
            }
            ;
        }

        private bool WriteFile(IFileHandler fh, HandlerEvent ret, string filePath)
        {
            try
            {
                _log.Guid = fh.FileId;
                using ( StreamWriter writer = new StreamWriter(filePath) {AutoFlush = true})
                {
                    writer.Write(fh.XmlBuffer);
                    writer.Close();
                    _log.Debug("File written");
                }
            }
            catch (Exception e)
            {
                ret.Event = EventEnum.FileWriteError;
                _log.Error("File write error");
                return false;
            }
            return true;
        }
    }
}