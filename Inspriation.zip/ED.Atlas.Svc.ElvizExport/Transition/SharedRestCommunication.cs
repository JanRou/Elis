﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using RestSharp;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public interface ISharedRestCommunication
    {
        IRestResponse RestResponse(string url, string requestUrl, Guid guid, string message);
    }

    public class SharedRestCommunication : ISharedRestCommunication
    {
        public IRestResponse RestResponse(string url, string requestUrl, Guid guid, string message)
        {
            IRestResponse result = null;
            try
            {                
                var client = new RestClient(url);
                var request = new RestRequest(requestUrl, Method.POST);

                request.AddJsonBody(
                    new ElvizStatusDto
                    {
                        Guid = guid,
                        Message = message
                    });

                result = client.Execute(request);
            }
            catch ( Exception ex )
            {
                // TODO Log the incidence
            }
            return result;
        }

    }
}
