﻿using System;
using System.Threading;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;
using ED.Atlas.Svc.ElvizExport.TimeoutMonitor;
using ED.Atlas.Svc.ElvizExport.Transition;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class RegisterFilehandleTransition : ITransition
    {
        private readonly IExportTimeoutMonitor _exportTimeoutMonitor;

        public RegisterFilehandleTransition(IExportTimeoutMonitor exportTimeoutMonitor)
        {
            _exportTimeoutMonitor = exportTimeoutMonitor;
        }

        IEvent ITransition.Execute(IFileHandler fh)
        {
            _exportTimeoutMonitor.Register(fh.FileId);

            return new HandlerEvent() {Event=EventEnum.None , Guid = fh.FileId};  // Issue non-event
        }
    }
}