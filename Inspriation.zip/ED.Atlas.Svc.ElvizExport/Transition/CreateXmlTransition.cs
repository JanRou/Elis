﻿using System;
using System.Reflection;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Sagas;
using log4net;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class CreateXmlTransition : ITransition
    {
        private readonly IElvizSerializerFactory _elvizSerializerFactory;
        private readonly IEdLog<CreateXmlTransition> _edLog;

        public CreateXmlTransition(IElvizSerializerFactory elvizSerializerFactory, IEdLog<CreateXmlTransition> edLog)
        {
            _elvizSerializerFactory = elvizSerializerFactory;
            _edLog = edLog;
        }

        IEvent ITransition.Execute(IFileHandler fh)
        {
            _edLog.Guid = fh.FileId;
            var ret = new HandlerEvent {Event = EventEnum.XmlCreated, Guid = fh.FileId};
            try
            {
                fh.XmlBuffer = _elvizSerializerFactory.Get(fh.DealType).Serialize(fh.Deal);
            }
            catch (Exception excep)
            {
                ret.Event = EventEnum.XmlCreationError;
                _edLog.Error(excep.Message);
            }
            return ret;
        }
    }
}