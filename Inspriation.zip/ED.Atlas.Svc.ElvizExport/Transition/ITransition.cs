﻿using ED.Atlas.Svc.ElvizExport.EventDispatcher;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public interface ITransition
    {
        IEvent Execute(IFileHandler fh);
    }
}
