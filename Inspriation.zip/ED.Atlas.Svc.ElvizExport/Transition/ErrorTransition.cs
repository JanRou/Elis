﻿using System;
using System.Net;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;
using RestSharp;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class ErrorTransition : ITransition
    {
        private readonly IFileHandlers _fileHandlers;
        private readonly string _fetchAtlasDealUrl;
        private readonly ISharedRestCommunication _sharedRestCommunication;

        public ErrorTransition(IFileHandlers fileHandlers, ISharedRestCommunication sharedRestCommunication, string fetchAtlasDealUrl)
        {
            _fileHandlers = fileHandlers;
            _fetchAtlasDealUrl = fetchAtlasDealUrl;
            _sharedRestCommunication = sharedRestCommunication;
        }

        public IEvent Execute(IFileHandler fh)
        {
            // TODO Publish message to Atlas Monitor
            string message = ElvizExportStatus.Failure.ToString(); // Overwrite ElvizExportStatus with failure
            IRestResponse response = _sharedRestCommunication.RestResponse(
                _fetchAtlasDealUrl, $"v1/deals/status", fh.FileId, message);

            // If everything went okay remove the filehandler
            if ( response?.StatusCode == HttpStatusCode.OK )
            {
                _fileHandlers.Remove(fh.FileId);
            }
            return new HandlerEvent() {Event = EventEnum.Done, Guid = fh.FileId};
        }
    }
}
