﻿namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public enum TransitionEnum
    {
          CreateXml = 0
        , WriteFile = 1
        , RegisterFilehandle = 2
        , HandleResult = 3
        , FinalizeFilehandling = 4
        , ErrorTransition = 5
    }
}
