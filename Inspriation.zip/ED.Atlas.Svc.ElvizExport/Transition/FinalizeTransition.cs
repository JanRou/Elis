﻿using System;
using System.Net;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;
using RestSharp;
using ElvizStatusDto = ED.Atlas.Svc.ElvizExport.AtlasDealDto.ElvizStatusDto;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class FinalizeTransition : ITransition
    {
        private readonly string _fetchAtlasDealUrl;
        private readonly IFileHandlers _fileHandlers;
        private readonly ISharedRestCommunication _sharedRestCommunication;

        public FinalizeTransition(IFileHandlers fileHandlers, ISharedRestCommunication sharedRestCommunication, string fetchAtlasDealUrl)
        {
            _fileHandlers = fileHandlers;
            _sharedRestCommunication = sharedRestCommunication;
            _fetchAtlasDealUrl = fetchAtlasDealUrl;
        }

        IEvent ITransition.Execute(IFileHandler fh)
        {
            IEvent ret = new HandlerEvent {Guid = fh.FileId, Event = EventEnum.Done};

            IRestResponse response = _sharedRestCommunication.RestResponse(
                    _fetchAtlasDealUrl, $"v1/deals/status", fh.FileId, fh.ElvizExportStatus.ToString());

            // If everything went okay remove the filehandler
            if ( response?.StatusCode != HttpStatusCode.OK)
            {
                // TODO Maybe create another error if communication with another service is lost?
                ret.Event = EventEnum.FinalizeError;
            }
            return ret;
        }
    }
}