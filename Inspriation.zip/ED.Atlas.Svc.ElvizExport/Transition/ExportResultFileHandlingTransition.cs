﻿using System;
using System.IO;
using System.Xml.Serialization;
using ED.Atlas.Svc.ElvizExport.AtlasDealDto;
using ED.Atlas.Svc.ElvizExport.Elviz;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;
using ED.Atlas.Svc.ElvizExport.TimeoutMonitor;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public class ExportResultFileHandlingTransition : ITransition
    {
        private readonly IExportTimeoutMonitor _exportTimeoutMonitor;
        private readonly string _elvizExportResultPath;

        public ExportResultFileHandlingTransition(IExportTimeoutMonitor exportTimeoutMonitor, string elvizExportResultPath)
        {
            _exportTimeoutMonitor = exportTimeoutMonitor;
            _elvizExportResultPath = elvizExportResultPath;
        }

        public IEvent Execute(IFileHandler fh)
        {
            _exportTimeoutMonitor.Unregister(fh.FileId);

            // Assume succes
            var handlerEvent = new HandlerEvent() { Event = EventEnum.OkResult, Guid = fh.FileId };
            fh.ElvizExportStatus = ElvizExportStatus.Active;

            var serializer = new XmlSerializer(typeof(DealResult));

            DealResult result = null;
            try
            {
                using (var sr = new StreamReader(_elvizExportResultPath + fh.FileId + ".xml"))
                {
                    result = (DealResult)serializer.Deserialize(sr);
                    sr.Close();
                }
            }
            catch (Exception e)
            {
                handlerEvent.Event = EventEnum.ResultXmlReadError;
            }

            if (result != null && result.Result == ResultType.Failure)
            {
                handlerEvent.Event = EventEnum.ErrorInResult;
                fh.ElvizExportStatus = ElvizExportStatus.Failure;
                fh.ExportErrorMessage = result.Message;
            }
            DeleteResultFile(_elvizExportResultPath + fh.FileId + ".xml");

            return handlerEvent;
        }

        private void DeleteResultFile(string s)
        {
            try
            {
                File.Delete(s);
            }
            catch (Exception excep)
            {
                // TODO log
            }
        }
    }
}
