﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ED.Atlas.Svc.ElvizExport.EventDispatcher;
using ED.Atlas.Svc.ElvizExport.Sagas;

namespace ED.Atlas.Svc.ElvizExport.Transition
{
    public static class TransitionExtensions
    {
        public static async Task ExecuteAsync(this ITransition transition, IFileHandler fileHandler,
            IEventQueue eventQueue)
        {
            IEvent evnt = await Task.Run(() => transition.Execute(fileHandler));
            if (!((evnt.Event == EventEnum.Done) || (evnt.Event == EventEnum.None)))
            {
                // Don't queue Done or None, as this means it finished
                eventQueue.Enqueue(evnt);
            }
        }
    }
}
