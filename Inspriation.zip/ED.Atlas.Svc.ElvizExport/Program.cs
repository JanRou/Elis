﻿using System;
using System.Configuration;
using System.Diagnostics;
using System.Reflection;
using ED.Atlas.Svc.ElvizExport.Log;
using ED.Atlas.Svc.ElvizExport.Settings;
using log4net.Config;
using Nancy.TinyIoc;
using Topshelf;

namespace ED.Atlas.Svc.ElvizExport
{
    // Remember to: netsh http add urlacl url=http://+:44070/ user=jaro
    internal class Program
    {
        private static void Main(string[] args)
        {
            // Register our types before Nancy starts
            TinyIocBootstrapper tinyIocBootstrapper = new TinyIocBootstrapper();
            tinyIocBootstrapper.Register();
            string fileVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;
            string displayName = String.Format($"{ConfigurationManager.AppSettings["ServiceDisplay"]}, v{fileVersion}");
            // Start service
            HostFactory.Run(configure =>
            {
                configure.Service<IMainService>(s =>
                {
                    s.ConstructUsing(name => TinyIoCContainer.Current.Resolve<IMainService>());
                    s.WhenStarted(tc => tc.Start());
                    s.WhenStopped(tc => tc.Stop());
                });

                configure.RunAsLocalSystem();
                configure.SetDisplayName(displayName);
                configure.SetDescription(ConfigurationManager.AppSettings["ServiceDescription"]);
                configure.SetServiceName(ConfigurationManager.AppSettings["ServiceName"]);
            });

        }
    }
}