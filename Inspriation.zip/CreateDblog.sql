USE [dblog]
GO

/****** Object:  Table [dbo].[Log]    Script Date: 12-12-2016 09:16:55 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Log](
	[Id] [INT] IDENTITY(1,1) NOT NULL,
	[Date] [DATETIME] NOT NULL,
	[Thread] [VARCHAR](255) NOT NULL,
	[Level] [VARCHAR](50) NOT NULL,
	[Logger] [VARCHAR](255) NOT NULL,
	[Message] [VARCHAR](4000) NOT NULL,
	[Guid] [VARCHAR](255) NULL,
	[Line] [VARCHAR](255) NULL,
	[Exception] [VARCHAR](2000) NULL
) ON [PRIMARY]

GO


